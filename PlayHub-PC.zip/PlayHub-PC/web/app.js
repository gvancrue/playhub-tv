/* PlayHub — "My library" (corre en el navegador del PC, servido por PlayHub.ps1) */
'use strict';

const $ = (sel, root = document) => root.querySelector(sel);
const h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const ICON = {
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>',
  upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7 9l5-5 5 5M4 20h16"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>',
};

const S = {
  st: null,
  view: null,
  step: 0,
  filter: 'tv',
  source: 'all',
  control: 'all',
  q: '',
  wizSel: null,          // Set de keys elegidas en el asistente
  editing: null,         // key del juego en el editor
  artTab: 'cover',
  art: {},               // cache de opciones: `${key}|${kind}` -> []
  lastGridSig: '',
};

// ------------------------------------------------------------------ API

async function api(path, body) {
  const opts = body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
  const r = await fetch(path, opts);
  let data = {};
  try { data = await r.json(); } catch { /* sin cuerpo */ }
  if (!r.ok && data.ok === undefined) data.ok = false;
  return data;
}

let toastTimer;
function toast(msg, isErr) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3200);
}

async function loadState() {
  try {
    S.st = await api('/api/state');
  } catch {
    $('#app').innerHTML = '<div class="wizard"><div class="card"><h1>PlayHub is not responding</h1><p class="lead">The PlayHub program on this PC is not running. Open it from the "PlayHub - My library" shortcut.</p></div></div>';
    S.view = null;
    return;
  }
  const needWizard = !S.st.configured || !S.st.setupDone;
  const view = needWizard ? 'wizard' : 'library';
  if (view !== S.view) {
    S.view = view;
    if (view === 'wizard') S.step = S.st.configured ? 3 : 0;
    renderAll();
  } else {
    refreshLive();
  }
}

setInterval(loadState, 3000);

// ------------------------------------------------------------------ utilidades de juegos

const games = () => (S.st ? S.st.games : []);
const byKey = (k) => games().find((g) => g.key === k);
const coverOf = (g) => g.custom.cover || g.defaults.cover;
const heroOf = (g) => g.custom.hero || g.defaults.hero;
const logoOf = (g) => g.custom.logo || g.defaults.logo;

function controllerBadge(g) {
  if (g.controller === 'full') return { cls: '', text: '🎮 Controller' };
  if (g.controller === 'partial') return { cls: '', text: '🎮 Partial' };
  if (g.controller === 'none') return { cls: 'kbm', text: '🖱️ Mouse & keyboard' };
  if (!g.metaDone) return { cls: '', text: 'Checking…' };
  return null;
}

const playsWithPad = (g) => g.controller === 'full' || g.controller === 'partial';

function matches(g) {
  if (S.q && !g.displayName.toLowerCase().includes(S.q.toLowerCase()) && !g.name.toLowerCase().includes(S.q.toLowerCase())) return false;
  if (S.source !== 'all' && g.source !== S.source) return false;
  if (S.control === 'pad' && !playsWithPad(g)) return false;
  if (S.control === 'kbm' && g.controller !== 'none') return false;
  if (S.control === 'unknown' && g.controller) return false;
  return true;
}

// Orden en el TV: el que definiste arrastrando; lo demás, alfabético (igual que en el TV).
function tvSort(list) {
  const ord = new Map(((S.st && S.st.order) || []).map((k, i) => [k, i]));
  return list.slice().sort((a, b) => {
    const oa = ord.has(a.key) ? ord.get(a.key) : 1e9, ob = ord.has(b.key) ? ord.get(b.key) : 1e9;
    return oa - ob || a.displayName.localeCompare(b.displayName, 'en', { sensitivity: 'base' });
  });
}

const canReorder = () => S.view !== 'wizard' && S.filter === 'tv' && !S.q && S.source === 'all' && S.control === 'all';

function filtered() {
  const list = filteredRaw();
  return S.view !== 'wizard' && S.filter === 'tv' ? tvSort(list) : list;
}

function filteredRaw() {
  return games().filter((g) => {
    if (!matches(g)) return false;
    if (S.view === 'wizard') return true;
    if (S.filter === 'tv') return g.enabled;
    if (S.filter === 'hidden') return !g.enabled;
    if (S.filter === 'new') return !g.decided;
    return true;
  });
}

function imgTag(src, alt, cls = '') {
  if (!src) return '';
  return `<img src="${esc(src)}" alt="${esc(alt)}" class="${cls}" loading="lazy" onerror="this.remove()">`;
}

// ------------------------------------------------------------------ render general

function renderAll() {
  const app = $('#app');
  app.innerHTML = '';
  if (S.view === 'wizard') app.appendChild(renderWizard());
  else app.appendChild(renderLibrary());
}

function refreshLive() {
  if (S.view === 'wizard') {
    if (S.step === 3) { updateWizardProgress(); renderGridIfChanged(); }
    return;
  }
  updateTop();
  updateBanners();
  updateSegCounts();
  renderGridIfChanged();
}

// ------------------------------------------------------------------ asistente

function stepsBar(n) {
  return `<div class="steps">${[0, 1, 2, 3, 4].map((i) => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div>`;
}

function renderWizard() {
  const w = h(`<div class="wizard"><div class="wizard-brand"><span class="brand-mark"></span>PlayHub</div>${stepsBar(S.step)}<div id="wizCard"></div></div>`);
  const card = $('#wizCard', w);
  const steps = [wizWelcome, wizSunshine, wizSgdb, wizGames, wizDone];
  card.replaceWith(steps[S.step]());
  return w;
}

function goStep(n) { S.step = n; renderAll(); window.scrollTo(0, 0); }

function wizWelcome() {
  const c = h(`<div class="card">
    <h1>Hi! Let's set up PlayHub</h1>
    <p class="lead">It takes about 2 minutes. When you're done, your games will be on the TV, ready to play.</p>
    <ul class="checklist">
      <li><span class="n">1</span><div><b>Connect to Sunshine.</b> With the same username and password as its web page.</div></li>
      <li><span class="n">2</span><div><b>More art (optional).</b> A free SteamGridDB key gives you lots of covers to choose from.</div></li>
      <li><span class="n">3</span><div><b>Pick your games.</b> Only the ones you check will show up on the TV.</div></li>
    </ul>
    <div class="card-actions"><span></span><button class="btn primary big" id="go">Get started</button></div>
  </div>`);
  $('#go', c).onclick = () => goStep(1);
  return c;
}

function sunshineForm(prefix, done) {
  const st = S.st || {};
  const f = h(`<div>
    <div id="${prefix}msg"></div>
    <label class="field"><span>Sunshine address</span><input class="input" id="${prefix}url" value="${esc(st.sunshineUrl || 'https://localhost:47990')}"><small>If Sunshine runs on this PC, leave it as is.</small></label>
    <label class="field"><span>Username</span><input class="input" id="${prefix}user" value="${esc(st.sunshineUser || '')}" autocomplete="username"></label>
    <label class="field"><span>Password</span><input class="input" type="password" id="${prefix}pass" placeholder="${st.configured ? 'Leave empty to keep it' : ''}" autocomplete="current-password"></label>
  </div>`);
  const submit = async (btn) => {
    const msg = $(`#${prefix}msg`, f);
    btn.disabled = true;
    const old = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Testing…';
    const r = await api('/api/sunshine', { url: $(`#${prefix}url`, f).value.trim(), user: $(`#${prefix}user`, f).value.trim(), password: $(`#${prefix}pass`, f).value });
    btn.disabled = false;
    btn.innerHTML = old;
    if (r.ok) { msg.innerHTML = '<div class="msg ok">Connected to Sunshine ✓</div>'; S.st = await api('/api/state'); done && done(); }
    else msg.innerHTML = `<div class="msg err">${esc(r.error || 'Could not connect.')}</div>`;
  };
  return { el: f, submit };
}

function wizSunshine() {
  const form = sunshineForm('ws', () => setTimeout(() => goStep(2), 500));
  const c = h(`<div class="card">
    <h1>Connect to Sunshine</h1>
    <p class="lead">Use the username and password you log in to Sunshine's web page with. They're stored encrypted on this PC.</p>
    <div id="form"></div>
    <div class="card-actions"><button class="btn ghost" id="back">Back</button><button class="btn primary big" id="go">Test and continue</button></div>
  </div>`);
  $('#form', c).replaceWith(form.el);
  $('#back', c).onclick = () => goStep(0);
  $('#go', c).onclick = (e) => form.submit(e.currentTarget);
  c.addEventListener('keydown', (e) => { if (e.key === 'Enter') form.submit($('#go', c)); });
  return c;
}

function sgdbForm(prefix, done) {
  const f = h(`<div>
    <div id="${prefix}msg"></div>
    <label class="field"><span>SteamGridDB API key</span><input class="input" id="${prefix}key" placeholder="${S.st && S.st.hasSgdbKey ? 'You already have a key saved' : 'Paste your key here'}">
    <small>Create a free account at <a href="https://www.steamgriddb.com" target="_blank">steamgriddb.com</a> → your profile → <b>Preferences</b> → <b>API</b> → <a href="https://www.steamgriddb.com/profile/preferences/api" target="_blank">Generate API Key</a>.</small></label>
  </div>`);
  const submit = async (btn) => {
    const key = $(`#${prefix}key`, f).value.trim();
    const msg = $(`#${prefix}msg`, f);
    if (!key) { done && done(); return; }
    btn.disabled = true;
    const old = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Testing…';
    const r = await api('/api/sgdb', { key });
    btn.disabled = false;
    btn.innerHTML = old;
    if (r.ok) { msg.innerHTML = '<div class="msg ok">Key saved ✓</div>'; S.art = {}; done && done(); }
    else msg.innerHTML = `<div class="msg err">${esc(r.error || 'That key didn\'t work.')}</div>`;
  };
  return { el: f, submit };
}

function wizSgdb() {
  const form = sgdbForm('wg', () => setTimeout(() => goStep(3), 400));
  const c = h(`<div class="card">
    <h1>More art for your games <span style="font-size:15px;color:var(--text-3);font-weight:600">· optional</span></h1>
    <p class="lead">Without it, PlayHub uses Steam's art and the images you upload. With a free SteamGridDB key you get hundreds of covers, backgrounds and logos to choose from, also for games that aren't on Steam.</p>
    <div id="form"></div>
    <div class="card-actions"><button class="btn ghost" id="skip">Skip for now</button><button class="btn primary big" id="go">Save and continue</button></div>
  </div>`);
  $('#form', c).replaceWith(form.el);
  $('#skip', c).onclick = () => goStep(3);
  $('#go', c).onclick = (e) => form.submit(e.currentTarget);
  return c;
}

function suggestedSelection() {
  return new Set(games().filter(playsWithPad).map((g) => g.key));
}

function wizGames() {
  if (!S.wizSel) S.wizSel = new Set(games().filter((g) => g.enabled).map((g) => g.key));
  const c = h(`<div class="card wide">
    <h1>Pick your games</h1>
    <p class="lead">Check the ones you want on the TV. <b>Mouse & keyboard</b> games are marked so you can leave them out. You can change this any time.</p>
    <div class="toolbar">
      <button class="btn small primary" id="sugg">🎮 Only controller games</button>
      <button class="btn small" id="all">All</button>
      <button class="btn small" id="none">None</button>
      <button class="btn small" id="addGame">＋ Add another game</button>
      <div class="search"><span>${ICON.search}</span><input class="input" id="q" placeholder="Search…" value="${esc(S.q)}"></div>
      <span class="count" id="wizProgress" style="margin:0 0 0 auto"></span>
    </div>
    <div id="grid"></div>
    <div class="card-actions"><button class="btn ghost" id="back">Back</button><button class="btn primary big" id="go">Continue</button></div>
  </div>`);
  $('#sugg', c).onclick = () => { S.wizSel = suggestedSelection(); forceGrid(); };
  $('#all', c).onclick = () => { filtered().forEach((g) => S.wizSel.add(g.key)); forceGrid(); };
  $('#none', c).onclick = () => { filtered().forEach((g) => S.wizSel.delete(g.key)); forceGrid(); };
  $('#addGame', c).onclick = () => openAddGame(async (g) => { S.wizSel.add(g.key); await loadState(); forceGrid(); });
  $('#q', c).oninput = (e) => { S.q = e.target.value; forceGrid(); };
  $('#back', c).onclick = () => goStep(S.st.configured ? 2 : 1);
  $('#go', c).onclick = async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const on = [...S.wizSel];
    const off = games().map((g) => g.key).filter((k) => !S.wizSel.has(k));
    await api('/api/select', { keys: on, enabled: true });
    if (off.length) await api('/api/select', { keys: off, enabled: false });
    goStep(4);
  };
  setTimeout(() => { updateWizardProgress(); forceGrid(); }, 0);
  return c;
}

function updateWizardProgress() {
  const el = $('#wizProgress');
  if (!el || !S.st) return;
  const n = S.wizSel ? S.wizSel.size : 0;
  const pend = S.st.pendingMeta;
  el.innerHTML = (pend ? `<span class="spinner"></span>&nbsp; Checking your games on Steam (${pend} left) · ` : '') + `<b>${n}</b> of ${games().length} selected`;
}

function wizDone() {
  const n = S.wizSel ? S.wizSel.size : games().filter((g) => g.enabled).length;
  const c = h(`<div class="card">
    <div class="done-icon">${ICON.check}</div>
    <h1>All set!</h1>
    <p class="lead">You picked <b>${n} game${n === 1 ? '' : 's'}</b>. PlayHub is adding them to Sunshine with their covers; it can take a couple of minutes.</p>
    <ul class="checklist">
      <li><span class="n">✓</span><div>PlayHub starts with Windows. <b>You don't need to open anything again</b>, just Sunshine.</div></li>
      <li><span class="n">✓</span><div>If you install a new game, it shows up here as <b>new</b> so you can decide if it goes to the TV.</div></li>
      <li><span class="n">✓</span><div>To change games or their art, open <b>"PlayHub - My library"</b> from the desktop.</div></li>
    </ul>
    <div class="card-actions"><span></span><button class="btn primary big" id="go">Go to my library</button></div>
  </div>`);
  $('#go', c).onclick = async () => {
    await api('/api/settings', { setupDone: true });
    S.wizSel = null; S.q = ''; S.filter = 'tv';
    S.view = null;
    loadState();
  };
  return c;
}

// ------------------------------------------------------------------ biblioteca

function renderLibrary() {
  const root = h(`<div>
    <div class="top"><div class="top-inner">
      <div class="brand"><span class="brand-mark"></span>PlayHub<small>My library</small></div>
      <div class="spacer"></div>
      <div class="status" id="stSync"></div>
      <div class="status" id="stTv"></div>
      <button class="btn small primary" id="addGame">＋ Add game</button>
      <button class="btn small" id="rescan">${ICON.refresh} Scan for games</button>
      <button class="btn small" id="settings">${ICON.gear} Settings</button>
    </div></div>
    <div class="main">
      <div id="banners"></div>
      <div class="toolbar">
        <div class="seg" id="seg">
          <button data-f="tv">On the TV<em></em></button>
          <button data-f="all">All<em></em></button>
          <button data-f="hidden">Hidden<em></em></button>
          <button data-f="new">New<em></em></button>
        </div>
        <div class="search"><span>${ICON.search}</span><input class="input" id="q" placeholder="Search games…" value="${esc(S.q)}"></div>
        <select class="input" id="source"><option value="all">All stores</option><option>Steam</option><option>Epic</option><option>GOG</option><option value="Manual">Added by you</option></select>
        <select class="input" id="control">
          <option value="all">Any input</option>
          <option value="pad">🎮 Controller</option>
          <option value="kbm">🖱️ Mouse & keyboard</option>
          <option value="unknown">Unknown</option>
        </select>
        <div class="bulk">
          <button class="btn small" id="bulkOn">Show these on the TV</button>
          <button class="btn small ghost" id="bulkOff">Hide these</button>
        </div>
      </div>
      <div class="count" id="count"></div>
      <div id="grid"></div>
    </div>
  </div>`);
  $('#source', root).value = S.source;
  $('#control', root).value = S.control;
  root.querySelectorAll('#seg button').forEach((b) => {
    b.onclick = () => { S.filter = b.dataset.f; updateSegCounts(); forceGrid(); };
  });
  $('#q', root).oninput = (e) => { S.q = e.target.value; forceGrid(); };
  $('#source', root).onchange = (e) => { S.source = e.target.value; forceGrid(); };
  $('#control', root).onchange = (e) => { S.control = e.target.value; forceGrid(); };
  $('#bulkOn', root).onclick = () => bulk(true);
  $('#bulkOff', root).onclick = () => bulk(false);
  $('#rescan', root).onclick = async () => { await api('/api/rescan', {}); toast('Scanning installed games…'); };
  $('#settings', root).onclick = openSettings;
  $('#addGame', root).onclick = () => openAddGame(async (g) => { await loadState(); S.filter = 'tv'; updateSegCounts(); forceGrid(); openEditor(g.key); });
  setTimeout(() => { updateTop(); updateBanners(); updateSegCounts(); forceGrid(); }, 0);
  return root;
}

function updateTop() {
  const st = S.st;
  const sync = $('#stSync'), tv = $('#stTv');
  if (!sync) return;
  const sunErr = /not responding|Missing/.test(st.syncMessage || '');
  sync.innerHTML = st.busy
    ? '<span class="spinner"></span> Updating…'
    : `<span class="dot ${sunErr ? 'bad' : 'ok'}"></span>${esc(sunErr ? st.syncMessage : 'Sunshine up to date')}`;
  sync.title = st.lastSync ? 'Last sync: ' + new Date(st.lastSync).toLocaleString('en') : '';
  tv.innerHTML = st.lanMode
    ? '<span class="dot ok"></span>The TV can see your library'
    : '<span class="dot warn"></span>The TV can\'t see your customizations';
  tv.title = st.lanMode ? '' : 'Run Install.bat again (as administrator) to allow access from the TV.';
}

function updateBanners() {
  const box = $('#banners');
  if (!box) return;
  const nNew = games().filter((g) => !g.decided).length;
  const conflicts = games().filter((g) => g.enabled && g.conflict);
  let html = '';
  if (nNew) {
    html += `<div class="banner"><div><b>${nNew} new game${nNew === 1 ? '' : 's'}</b> since last time. Decide if they go to the TV.</div><div class="spacer"></div>
      <button class="btn small primary" data-a="review">Review</button><button class="btn small ghost" data-a="dismiss">Keep them hidden</button></div>`;
  }
  if (conflicts.length) {
    html += `<div class="banner warn"><div><b>${esc(conflicts.map((g) => g.displayName).join(', '))}</b>: an app with that name already exists in Sunshine (you created it). Rename the game here or delete that app in Sunshine.</div></div>`;
  }
  box.innerHTML = html;
  box.querySelectorAll('[data-a]').forEach((b) => {
    b.onclick = async () => {
      if (b.dataset.a === 'review') { S.filter = 'new'; updateSegCounts(); forceGrid(); }
      else { await api('/api/decide-all', {}); await loadState(); updateBanners(); }
    };
  });
}

function updateSegCounts() {
  const all = games().filter(matches);
  const counts = { tv: all.filter((g) => g.enabled).length, all: all.length, hidden: all.filter((g) => !g.enabled).length, new: all.filter((g) => !g.decided).length };
  document.querySelectorAll('#seg button').forEach((b) => {
    b.classList.toggle('on', b.dataset.f === S.filter);
    $('em', b).textContent = counts[b.dataset.f];
  });
}

async function bulk(on) {
  const keys = filtered().map((g) => g.key);
  if (!keys.length) return;
  if (keys.length > 15 && !confirm(`${on ? 'Show' : 'Hide'} ${keys.length} games?`)) return;
  await api('/api/select', { keys, enabled: on });
  toast(on ? `${keys.length} games will go to the TV` : `${keys.length} games hidden`);
  await loadState();
  forceGrid();
}

// ------------------------------------------------------------------ cuadrícula

function gridSig() {
  const list = filtered();
  return JSON.stringify([S.view, S.filter === 'tv' ? (S.st && S.st.order) : 0, S.view === 'wizard' ? [...(S.wizSel || [])].sort() : 0, list.map((g) => [g.key, g.enabled, g.decided, g.controller, g.metaDone, coverOf(g), g.displayName, g.conflict])]);
}

function renderGridIfChanged() {
  const sig = gridSig();
  if (sig !== S.lastGridSig) renderGrid(sig);
}

function forceGrid() { renderGrid(gridSig()); if (S.view === 'wizard') updateWizardProgress(); else updateSegCounts(); }

function renderGrid(sig) {
  const box = $('#grid');
  if (!box) return;
  S.lastGridSig = sig;
  const list = filtered();
  const wiz = S.view === 'wizard';
  const count = $('#count');
  if (count) {
    count.innerHTML = list.length ? esc(`${list.length} game${list.length === 1 ? '' : 's'}`) : '';
    if (list.length > 1 && canReorder()) {
      count.innerHTML += ' · <span class="hint">Drag the covers to change the order on the TV</span>' +
        ((S.st.order || []).length ? ' <button class="btn small ghost" id="sortAZ">Sort A-Z</button>' : '');
      const az = $('#sortAZ');
      if (az) az.onclick = async () => { S.st.order = []; forceGrid(); await api('/api/order', { reset: true }); toast('Alphabetical order'); };
    } else if (list.length > 1 && S.filter === 'tv') {
      count.innerHTML += ' · <span class="hint">Clear the search and filters to change the order</span>';
    }
  }
  if (!list.length) {
    let txt = 'No matching games.';
    if (!games().length) txt = S.st && S.st.busy ? 'Looking for your installed games…' : 'No Steam, Epic or GOG games found on this PC.';
    else if (!wiz && S.filter === 'tv' && !S.q) txt = 'No games on the TV yet. Go to "All" and turn on the ones you want.';
    else if (!wiz && S.filter === 'new') txt = 'No new games.';
    box.innerHTML = `<div class="empty">${esc(txt)}</div>`;
    return;
  }
  const grid = h('<div class="grid"></div>');
  const reorder = canReorder() && list.length > 1;
  for (const g of list) {
    const on = wiz ? S.wizSel.has(g.key) : g.enabled;
    const cb = controllerBadge(g);
    const badges = [];
    if (!wiz && !g.decided) badges.push('<span class="badge new">NEW</span>');
    if (cb) badges.push(`<span class="badge ${cb.cls}">${cb.text}</span>`);
    if (!wiz && g.enabled && g.conflict) badges.push('<span class="badge warn">Duplicate name</span>');
    const el = h(`<div class="game ${on ? (wiz ? 'sel' : '') : 'off'}">
      <div class="art">
        <div class="ph">${esc(g.displayName)}</div>
        ${imgTag(coverOf(g), g.displayName)}
        <div class="badges">${badges.join('')}</div>
        ${wiz ? `<div class="check">${ICON.check}</div>` : '<div class="edit-hint">Customize</div>'}
      </div>
      <div class="meta"><div class="name" title="${esc(g.displayName)}">${esc(g.displayName)}</div>${wiz ? '' : `<button class="switch ${on ? 'on' : ''}" title="${on ? 'On the TV' : 'Hidden'}"></button>`}</div>
      <div class="sub">${g.manual ? 'Added by you' : esc(g.source)}${g.custom.name || g.custom.cover || g.custom.hero || g.custom.logo || g.custom.description || g.custom.controller || g.custom.fullscreen || g.custom.platform || g.custom.mouse || g.custom.hideTag || g.custom.year ? ' · customized' : ''}</div>
    </div>`);
    if (reorder) enableDrag(el, g, grid);
    if (wiz) {
      el.onclick = () => {
        if (S.wizSel.has(g.key)) S.wizSel.delete(g.key); else S.wizSel.add(g.key);
        el.classList.toggle('sel');
        el.classList.toggle('off', !S.wizSel.has(g.key));
        S.lastGridSig = gridSig();
        updateWizardProgress();
      };
    } else {
      $('.art', el).onclick = () => openEditor(g.key);
      $('.switch', el).onclick = async (e) => {
        e.stopPropagation();
        const next = !g.enabled;
        g.enabled = next; g.decided = true;
        forceGrid();
        updateBanners();
        const r = await api('/api/select', { keys: [g.key], enabled: next });
        if (!r.ok) toast('Could not save', true);
        else toast(next ? `${g.displayName} will go to the TV` : `${g.displayName} hidden from the TV`);
      };
    }
    grid.appendChild(el);
  }
  box.innerHTML = '';
  box.appendChild(grid);
}

// ------------------------------------------------------------------ arrastrar para ordenar

function enableDrag(el, g, grid) {
  el.draggable = true;
  el.dataset.key = g.key;
  el.addEventListener('dragstart', (e) => {
    S.dragKey = g.key;
    el.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', g.key); } catch { /* nada */ }
  });
  el.addEventListener('dragend', () => {
    el.classList.remove('dragging');
    grid.querySelectorAll('.drop-before, .drop-after').forEach((x) => x.classList.remove('drop-before', 'drop-after'));
    S.dragKey = null;
  });
  el.addEventListener('dragover', (e) => {
    if (!S.dragKey || S.dragKey === g.key) return;
    e.preventDefault();
    const r = el.getBoundingClientRect();
    const after = e.clientX > r.left + r.width / 2;
    el.classList.toggle('drop-after', after);
    el.classList.toggle('drop-before', !after);
  });
  el.addEventListener('dragleave', () => el.classList.remove('drop-before', 'drop-after'));
  el.addEventListener('drop', async (e) => {
    e.preventDefault();
    const from = S.dragKey;
    const after = el.classList.contains('drop-after');
    el.classList.remove('drop-before', 'drop-after');
    if (!from || from === g.key) return;
    const keys = filtered().map((x) => x.key).filter((k) => k !== from);
    let i = keys.indexOf(g.key);
    if (after) i++;
    keys.splice(i, 0, from);
    S.st.order = keys;
    forceGrid();
    const r = await api('/api/order', { keys });
    if (!r.ok) toast('Could not save the order', true);
    else toast('Order saved. The TV uses it next time you open PlayHub.');
  });
}

// ------------------------------------------------------------------ editor de un juego

function openEditor(key) {
  S.editing = key;
  S.artTab = 'cover';
  renderEditor();
}

function closeEditor() {
  S.editing = null;
  document.querySelectorAll('.drawer, .drawer-bg').forEach((e) => e.remove());
  forceGrid();
}

function renderEditor() {
  document.querySelectorAll('.drawer, .drawer-bg').forEach((e) => e.remove());
  const g = byKey(S.editing);
  if (!g) return;
  const bg = h('<div class="drawer-bg"></div>');
  bg.onclick = closeEditor;
  const d = h(`<div class="drawer">
    <div class="drawer-head"><h2>${esc(g.displayName)}</h2>
      <button class="switch ${g.enabled ? 'on' : ''}" id="edEnabled" title="On the TV"></button><span style="font-size:13px;color:var(--text-2)">On the TV</span>
      <button class="btn small ghost" id="close">${ICON.close}</button></div>
    <div class="drawer-body">
      <div id="preview"></div>
      <div class="preview-label">How it will look on the TV</div>

      ${g.manual ? `<div class="manual-box"><div><b>File</b><span title="${esc(g.path)}">${esc(g.path || '')}</span></div><button class="btn small ghost" id="removeManual">Remove from PlayHub</button></div>` : ''}
      <div class="section-title">Text</div>
      <label class="field"><span>Name</span><input class="input" id="edName" value="${esc(g.custom.name || '')}" placeholder="${esc(g.name)}"><small>Leave empty to use the original name.</small></label>
      <label class="field"><span>Release year</span><input class="input" id="edYear" style="max-width:160px" inputmode="numeric" maxlength="4" value="${esc(g.custom.year || '')}" placeholder="${esc(g.autoYear || 'e.g. 1994')}"><small>${g.autoYear ? 'Leave empty to use the automatic one.' : 'No automatic year found for this game.'}</small></label>
      <label class="field"><span>Description</span><textarea class="input" id="edDesc" placeholder="${esc(g.defaults.description || 'No description. Write one if you like.')}">${esc(g.custom.description || '')}</textarea><small>${g.defaults.description ? `Empty = the automatic one (${esc(g.descSource && g.descSource !== 'You' ? g.descSource : 'Steam')}).` : 'No automatic description found.'} <a href="#" id="wiki">Search Wikipedia</a></small></label>
      <div style="display:flex;gap:8px"><button class="btn primary small" id="saveText">Save text</button><span id="textMsg" style="font-size:13px;color:var(--text-3);align-self:center"></span></div>

      <div class="section-title">Playing</div>
      <label class="field"><span>Controls tag on the TV</span>
        <select class="input" id="edCtl">
          <option value="">Automatic${g.autoController ? ' (Steam: ' + ({ full: 'controller', partial: 'partial controller', none: 'mouse & keyboard' }[g.autoController] || g.autoController) + ')' : ''}</option>
          <option value="full">🎮 Works with a controller</option>
          <option value="partial">🎮 Partial controller support</option>
          <option value="none">🖱️ Requires mouse & keyboard</option>
        </select>
        <small>If Steam is wrong (for example, you play it with a controller anyway), change it here and the "mouse & keyboard" tag goes away.</small></label>
      <label class="field"><span>Show the controls tag on the TV</span>
        <select class="input" id="edTag"><option value="">Yes (only "partial" or "mouse & keyboard" are shown)</option><option value="hide">No, never</option></select></label>
      <label class="field"><span>Mouse pointer while playing</span>
        <select class="input" id="edMouse">
          <option value="">Automatic (${g.hideMouseAuto ? 'hidden' : 'visible, it\'s a mouse & keyboard game'})</option>
          <option value="hide">Hide it</option>
          <option value="show">Show it</option>
        </select>
        <small>Hides the Windows pointer during the game and brings it back when you quit.</small></label>
      <label class="field"><span>Original console</span>
        <select class="input" id="edPlat">
          <option value="">Automatic${g.autoPlatform ? ' (' + esc(g.autoPlatform) + ')' : ' (PC)'}</option>
          ${(S.st.platforms || []).map((p) => `<option value="${esc(p)}">${esc(p)}</option>`).join('')}
        </select>
        <small>Shown as a tag on the TV (not shown for PC games).</small></label>
      <label class="field"><span>Fullscreen</span>
        <select class="input" id="edFs" ${g.canFullscreen ? '' : 'disabled'}>
          <option value="">Off (open it as it is)</option>
          <option value="borderless">Borderless fullscreen (recommended)</option>
          <option value="altenter">Press Alt+Enter after it opens</option>
          <option value="f11">Press F11 after it opens</option>
        </select>
        <small>${g.canFullscreen ? 'For games that open in a window. PlayHub stretches the game window to cover the whole screen. If the game has its own fullscreen shortcut, try Alt+Enter or F11.' : 'Only for games added as an .exe (＋ Add game). Steam, Epic and GOG games use their own settings.'}</small></label>
      <span id="playMsg" style="font-size:13px;color:var(--text-3)"></span>

      <div class="section-title">Images</div>
      <div class="tabs" id="tabs">
        <button data-k="cover">Cover</button><button data-k="hero">Background</button><button data-k="logo">Logo</button>
      </div>
      <div id="artBox"></div>
    </div>
  </div>`);
  document.body.append(bg, d);
  $('#close', d).onclick = closeEditor;
  document.addEventListener('keydown', escClose);
  $('#edEnabled', d).onclick = async (e) => {
    const next = !g.enabled;
    e.currentTarget.classList.toggle('on', next);
    g.enabled = next; g.decided = true;
    await api('/api/select', { keys: [g.key], enabled: next });
    renderPreview(g);
  };
  const name = $('#edName', d), desc = $('#edDesc', d);
  const yearIn = $('#edYear', d);
  name.oninput = desc.oninput = yearIn.oninput = () => renderPreview(g, { name: name.value, description: desc.value, year: yearIn.value });
  $('#saveText', d).onclick = async () => {
    const r = await api('/api/game', { key: g.key, name: name.value, description: desc.value, year: $('#edYear', d).value });
    if (r.ok) { replaceGame(r.game); $('#textMsg', d).textContent = 'Saved ✓'; $('.drawer-head h2', d).textContent = r.game.displayName; }
    else toast(r.error || 'Could not save', true);
  };
  const ctl = $('#edCtl', d), fs = $('#edFs', d);
  ctl.value = g.custom.controller || '';
  fs.value = g.custom.fullscreen || '';
  const savePlay = async (field, value) => {
    const r = await api('/api/game', { key: g.key, [field]: value });
    if (!r.ok) return toast(r.error || 'Could not save', true);
    replaceGame(r.game);
    renderPreview(r.game, { name: name.value, description: desc.value, year: yearIn.value });
    $('#playMsg', d).textContent = 'Saved ✓' + (field === 'fullscreen' || field === 'mouse' ? ' Sunshine gets updated in a few seconds.' : ' The TV picks it up next time you open PlayHub.');
  };
  ctl.onchange = () => savePlay('controller', ctl.value);
  const tag = $('#edTag', d);
  tag.value = g.custom.hideTag ? 'hide' : '';
  tag.onchange = () => savePlay('hideTag', tag.value === 'hide');
  const mouse = $('#edMouse', d), plat = $('#edPlat', d);
  mouse.value = g.custom.mouse || '';
  plat.value = g.custom.platform || '';
  mouse.onchange = () => savePlay('mouse', mouse.value);
  plat.onchange = () => savePlay('platform', plat.value);
  fs.onchange = () => savePlay('fullscreen', fs.value);
  $('#wiki', d).onclick = async (e) => {
    e.preventDefault();
    const a = e.currentTarget;
    a.textContent = 'Searching…';
    const r = await api('/api/describe', { key: g.key, name: name.value.trim() || undefined });
    a.textContent = 'Search Wikipedia';
    if (!r.ok) return toast(r.error || 'Nothing found', true);
    desc.value = r.text;
    renderPreview(g, { name: name.value, description: desc.value });
    $('#textMsg', d).textContent = `From ${r.source}. Check it and hit "Save text".`;
  };
  d.querySelectorAll('#tabs button').forEach((b) => { b.onclick = () => { S.artTab = b.dataset.k; renderArt(); }; });
  const rm = $('#removeManual', d);
  if (rm) rm.onclick = async () => {
    if (!confirm(`Remove "${g.displayName}" from PlayHub? The file is not deleted from your PC.`)) return;
    const r = await api('/api/manual/remove', { key: g.key });
    if (!r.ok) { toast(r.error || 'Could not remove', true); return; }
    toast(`${g.displayName} removed`);
    closeEditor();
    await loadState();
    forceGrid();
  };
  renderPreview(g);
  renderArt();
}

function escClose(e) { if (e.key === 'Escape' && S.editing) { closeEditor(); document.removeEventListener('keydown', escClose); } }

function replaceGame(ng) {
  const list = games();
  const i = list.findIndex((x) => x.key === ng.key);
  if (i >= 0) list[i] = ng;
}

function renderPreview(g, draft = {}) {
  const box = $('#preview');
  if (!box) return;
  const title = draft.name !== undefined ? (draft.name.trim() || g.name) : g.displayName;
  const desc = draft.description !== undefined ? (draft.description.trim() || g.defaults.description) : g.description;
  const hero = heroOf(g), logo = logoOf(g), cover = coverOf(g);
  const others = games().filter((x) => x.enabled && x.key !== g.key).slice(0, 5);
  // La misma línea de datos que muestra el TV: aviso de control, consola, año.
  const year = draft.year !== undefined ? (draft.year.trim() || g.autoYear) : (g.custom.year || g.autoYear);
  const plat = g.custom.platform || g.autoPlatform;
  const chips = [];
  if (!g.custom.hideTag && g.controller === 'partial') chips.push('<span class="pv-chip">Partial controller support</span>');
  if (!g.custom.hideTag && g.controller === 'none') chips.push('<span class="pv-chip kbm">Requires mouse and keyboard</span>');
  const bits = [plat && plat !== 'PC' ? plat : '', year || ''].filter(Boolean).map(esc);
  const metaRow = chips.join('') + bits.join('<span class="pv-sep">•</span>');
  box.innerHTML = `<div class="preview">
    <div class="pv-bg" style="${hero ? `background-image:url('${esc(hero)}')` : ''}"></div>
    <div class="pv-shade"></div>
    <div class="pv-info">
      ${logo ? `<img class="pv-logo" src="${esc(logo)}" onerror="this.nextElementSibling.style.display='block';this.remove()"><div class="pv-title" style="display:none">${esc(title)}</div>` : `<div class="pv-title">${esc(title)}</div>`}
      ${metaRow ? `<div class="pv-meta">${metaRow}</div>` : ''}
      <div class="pv-desc">${esc(desc || '')}</div>
      <span class="pv-play">▶ Play</span>
    </div>
    <div class="pv-row"><div class="cur" style="${cover ? `background-image:url('${esc(cover)}')` : ''}"></div>${others.map((o) => `<div style="${coverOf(o) ? `background-image:url('${esc(coverOf(o))}')` : ''}"></div>`).join('')}</div>
  </div>`;
  // El logo con el mismo tamaño "por área" que usa el TV (escalado al ancho de la vista previa).
  const img = $('.pv-logo', box);
  if (img) img.onload = () => {
    const k = box.clientWidth / 1920, r = img.naturalWidth / img.naturalHeight;
    if (!r) return;
    let w = Math.sqrt(420 * 140 * r) * k, hh = w / r;
    const f = Math.min(1, (620 * k) / w, (180 * k) / hh);
    img.style.width = Math.round(w * f) + 'px'; img.style.height = Math.round(hh * f) + 'px';
    img.style.maxWidth = 'none'; img.style.maxHeight = 'none';
  };
}

async function renderArt() {
  const g = byKey(S.editing);
  const box = $('#artBox');
  if (!g || !box) return;
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.k === S.artTab));
  const kind = S.artTab;
  const label = { cover: 'covers', hero: 'backgrounds', logo: 'logos' }[kind];
  const hasCustom = !!g.custom[kind];
  box.innerHTML = `
    <div class="art-actions">
      <button class="btn small" id="up">${ICON.upload} Upload image</button>
      <button class="btn small ghost" id="reset" ${hasCustom ? '' : 'disabled'}>${ICON.undo} Use the original</button>
      <span class="note">${kind === 'cover' ? 'Portrait, ideally 600×900.' : kind === 'hero' ? 'Wide and large, ideally 1920×620 or bigger.' : 'PNG with a transparent background.'}</span>
    </div>
    ${S.st.hasSgdbKey ? `<div class="sgdb-pick">SteamGridDB art for <b>${esc(g.custom.sgdbName || g.displayName)}</b>${g.custom.sgdbName ? ' (chosen by you)' : ''} · <a href="#" id="sgOpen">Search another game</a>${g.custom.sgdbName ? ' · <a href="#" id="sgAuto">Back to automatic</a>' : ''}
      <div id="sgBox" class="hidden"><div style="display:flex;gap:8px;margin-top:10px"><input class="input" id="sgQ" placeholder="e.g. Link's Awakening DX"><button class="btn small" id="sgGo">${ICON.search} Search</button></div><div id="sgRes"></div></div></div>` : ''}
    ${S.st.hasSgdbKey ? '' : `<div class="sgdb-hint">Want many more ${label} to choose from? Add a free SteamGridDB key in <a href="#" id="toSettings">Settings</a>.</div>`}
    <div id="opts"><div class="loading-row"><span class="spinner"></span> Looking for options…</div></div>`;
  $('#up', box).onclick = () => pickFile(g, kind);
  $('#reset', box).onclick = () => setImage(g, kind, { reset: true });
  const sgOpen = $('#sgOpen', box);
  if (sgOpen) {
    const pick = async (id, name) => {
      const r = await api('/api/sgdb-pick', { key: g.key, id, name });
      if (!r.ok) return toast(r.error || 'Could not save', true);
      replaceGame(r.game);
      Object.keys(S.art).forEach((k) => { if (k.startsWith(g.key + '|')) delete S.art[k]; });
      toast(id ? `Showing art for ${name}` : 'Back to automatic');
      renderArt();
    };
    sgOpen.onclick = (e) => { e.preventDefault(); $('#sgBox', box).classList.remove('hidden'); const q = $('#sgQ', box); q.value = g.displayName; q.focus(); q.select(); };
    const auto = $('#sgAuto', box);
    if (auto) auto.onclick = (e) => { e.preventDefault(); pick(null, null); };
    const search = async () => {
      const res = $('#sgRes', box);
      res.innerHTML = '<div class="loading-row"><span class="spinner"></span> Searching…</div>';
      const r = await api('/api/sgdb-search', { q: $('#sgQ', box).value.trim() });
      if (!r.ok) { res.innerHTML = `<div class="msg err">${esc(r.error || 'Search failed')}</div>`; return; }
      if (!r.results.length) { res.innerHTML = '<div class="empty" style="padding:12px">Nothing found. Try another name.</div>'; return; }
      res.innerHTML = r.results.map((x) => `<button class="sg-hit" data-id="${x.id}" data-name="${esc(x.name)}">${esc(x.name)}${x.year ? ` <span>${x.year}</span>` : ''}</button>`).join('');
      res.querySelectorAll('.sg-hit').forEach((b) => { b.onclick = () => pick(+b.dataset.id, b.dataset.name); });
    };
    $('#sgGo', box).onclick = search;
    $('#sgQ', box).onkeydown = (e) => { if (e.key === 'Enter') search(); };
  }
  const ts = $('#toSettings', box);
  if (ts) ts.onclick = (e) => { e.preventDefault(); openSettings(); };

  const ck = `${g.key}|${kind}`;
  if (!S.art[ck]) {
    const r = await api(`/api/art?key=${encodeURIComponent(g.key)}&kind=${kind}`);
    S.art[ck] = r.ok ? r.options : [];
  }
  if (S.editing !== g.key || S.artTab !== kind) return;
  const opts = $('#opts');
  const list = S.art[ck];
  if (!list.length) {
    opts.innerHTML = `<div class="empty" style="padding:30px">No automatic options found. Upload your own image.</div>`;
    return;
  }
  const grid = h(`<div class="options ${kind}"></div>`);
  list.forEach((o) => {
    const isOn = g.custom[kind] ? g.custom[kind] === o.url : (o.source === 'Steam' && list.indexOf(o) === 0);
    const el = h(`<div class="opt ${isOn ? 'on' : ''}" title="${esc(o.author ? 'by ' + o.author : o.source)}">
      <img src="${esc(o.thumb || o.url)}" loading="lazy" onerror="this.closest('.opt').remove()">
      <span class="src">${esc(o.source)}</span><span class="tick">${ICON.check}</span></div>`);
    el.onclick = () => setImage(g, kind, o.source === 'Steam' && list.indexOf(o) === 0 ? { reset: true } : { url: o.url });
    grid.appendChild(el);
  });
  opts.innerHTML = '';
  opts.appendChild(grid);
}

async function setImage(g, kind, payload) {
  const r = await api('/api/image', Object.assign({ key: g.key, kind }, payload));
  if (!r.ok) { toast(r.error || 'Could not save the image', true); return; }
  replaceGame(r.game);
  toast(payload.reset ? 'Back to the original' : 'Image updated');
  renderPreview(r.game);
  renderArt();
}

function pickFile(g, kind) {
  const input = $('#filePicker');
  input.value = '';
  input.onchange = () => {
    const f = input.files[0];
    if (!f) return;
    if (f.size > 15 * 1024 * 1024) { toast('The image is too big (max. 15 MB)', true); return; }
    const reader = new FileReader();
    reader.onload = () => setImage(g, kind, { data: reader.result });
    reader.readAsDataURL(f);
  };
  input.click();
}

// ------------------------------------------------------------------ agregar un juego (.exe, acceso directo…)

function openAddGame(onAdded) {
  const bg = h('<div class="drawer-bg" style="z-index:40"></div>');
  const m = h(`<div class="modal">
    <h2>Add a game or program</h2>
    <p style="color:var(--text-2);line-height:1.5;margin:-8px 0 20px">Any game PlayHub didn't find on its own: an <b>.exe</b>, a <b>shortcut</b> (.lnk / .url) or a <b>.bat</b>. Emulators, Xbox, EA, Ubisoft, Battle.net games, whatever you want.</p>
    <div id="msg"></div>
    <label class="field"><span>File</span>
      <div style="display:flex;gap:8px"><input class="input" id="path" placeholder="C:\Games\MyGame\game.exe"><button class="btn" id="browse">Browse…</button></div>
      <small>Use "Browse…" or paste the full path. Tip: in File Explorer, Shift + right-click the file → "Copy as path".</small></label>
    <label class="field"><span>Name on the TV</span><input class="input" id="name" placeholder="Filled in when you pick the file"></label>
    <details style="margin-bottom:16px"><summary style="cursor:pointer;color:var(--text-2);font-size:13px">Advanced options</summary>
      <label class="field" style="margin-top:12px"><span>Arguments (optional)</span><input class="input" id="args" placeholder="E.g.: -fullscreen"><small>Added when the program opens. Useful for emulators: the ROM path, for example.</small></label>
    </details>
    <div style="display:flex;justify-content:flex-end;gap:8px"><button class="btn ghost" id="cancel">Cancel</button><button class="btn primary" id="add">Add</button></div>
  </div>`);
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const close = () => { bg.remove(); m.remove(); clearInterval(poll); document.removeEventListener('keydown', onKey); };
  document.addEventListener('keydown', onKey);
  let poll = null;
  let nameTouched = false;
  const msg = $('#msg', m), pathIn = $('#path', m), nameIn = $('#name', m);
  nameIn.oninput = () => { nameTouched = true; };
  const suggest = async () => {
    const p = pathIn.value.trim().replace(/^"|"$/g, '');
    if (!p || nameTouched) return;
    const r = await api('/api/suggest-name', { path: p });
    if (r.ok && !nameTouched) nameIn.value = r.name;
  };
  pathIn.onchange = suggest;
  pathIn.onpaste = () => setTimeout(suggest, 50);
  bg.onclick = close;
  $('#cancel', m).onclick = close;
  $('#browse', m).onclick = async (e) => {
    const btn = e.currentTarget;
    const r = await api('/api/pick-file', {});
    if (!r.ok) { msg.innerHTML = `<div class="msg err">${esc(r.error)}</div>`; return; }
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Pick in the window…';
    msg.innerHTML = '<div class="msg ok">The Windows file picker opened. If you don\'t see it, check the taskbar.</div>';
    clearInterval(poll);
    poll = setInterval(async () => {
      const res = await api('/api/pick-file-result', {});
      if (res.pending) return;
      clearInterval(poll);
      btn.disabled = false;
      btn.textContent = 'Browse…';
      msg.innerHTML = '';
      if (res.path) {
        pathIn.value = res.path;
        if (!nameTouched) nameIn.value = res.name || '';
      }
    }, 700);
  };
  $('#add', m).onclick = async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    const r = await api('/api/manual/add', { path: pathIn.value, name: nameIn.value, args: $('#args', m).value });
    btn.disabled = false;
    if (!r.ok) { msg.innerHTML = `<div class="msg err">${esc(r.error || 'Could not add')}</div>`; return; }
    close();
    toast(`${r.game.displayName} added. Pick its cover and background.`);
    onAdded && onAdded(r.game);
  };
  document.body.append(bg, m);
  pathIn.focus();
}

// ------------------------------------------------------------------ ajustes

function openSettings() {
  const bg = h('<div class="drawer-bg" style="z-index:40"></div>');
  const sun = sunshineForm('ss');
  const sg = sgdbForm('sg');
  const m = h(`<div class="modal">
    <h2>Settings</h2>
    <div class="section-title" style="margin-top:0">Sunshine</div>
    <div id="sun"></div>
    <button class="btn small" id="sunSave">Test and save</button>
    <hr>
    <div class="section-title" style="margin-top:0">SteamGridDB ${S.st.hasSgdbKey ? '<span style="color:var(--ok)">· active</span>' : ''}</div>
    <div id="sg"></div>
    <div style="display:flex;gap:8px"><button class="btn small" id="sgSave">Save key</button>${S.st.hasSgdbKey ? '<button class="btn small ghost" id="sgDel">Remove key</button>' : ''}</div>
    <hr>
    <div class="section-title" style="margin-top:0">Console icons</div>
    <p style="color:var(--text-2);font-size:13px;line-height:1.5;margin:-4px 0 12px">Optional: a small icon for each console, shown next to its name on the TV (e.g. on EarthBound's page). Use a PNG with a transparent background, about 128 px tall.</p>
    <div id="picons"></div>
    <hr>
    <label class="toggle-row" id="auto"><div><b>Add new games to the TV automatically</b><span>If off, games you install stay as "new" until you decide.</span></div><button class="switch ${S.st.autoAddNew ? 'on' : ''}"></button></label>
    <hr>
    <div style="display:flex;justify-content:space-between;align-items:center"><button class="btn small ghost" id="wizard">Run the setup wizard again</button><button class="btn primary" id="close">Done</button></div>
  </div>`);
  const renderIcons = () => {
    const icons = new Map((S.st.platformIcons || []).map((x) => [x.platform, x.url]));
    // Primero las consolas de tus juegos; después todas las demás.
    const list = [...new Set([...(S.st.platformsInUse || []), ...icons.keys(), ...(S.st.platforms || []).filter((p) => p !== 'PC')])];
    const box = $('#picons', m);
    if (!list.length) { box.innerHTML = '<div style="color:var(--text-3);font-size:13px;margin-bottom:12px">None of your TV games has a console set yet (it\'s detected for emulators and recomps, or set it in each game).</div>'; return; }
    box.innerHTML = list.map((p) => `<div class="picon-row"><div class="picon">${icons.get(p) ? `<img src="${esc(icons.get(p))}">` : ''}</div><b>${esc(p)}</b><span class="spacer"></span>
      <button class="btn small" data-up="${esc(p)}">${ICON.upload} ${icons.get(p) ? 'Change' : 'Upload'}</button>${icons.get(p) ? `<button class="btn small ghost" data-rm="${esc(p)}">Remove</button>` : ''}</div>`).join('');
    box.querySelectorAll('[data-up]').forEach((b) => { b.onclick = () => {
      const input = $('#filePicker');
      input.value = '';
      input.onchange = () => {
        const f = input.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = async () => {
          const r = await api('/api/platform-icon', { platform: b.dataset.up, data: reader.result });
          if (!r.ok) return toast(r.error || 'Could not save', true);
          S.st = await api('/api/state'); renderIcons(); toast('Icon saved');
        };
        reader.readAsDataURL(f);
      };
      input.click();
    }; });
    box.querySelectorAll('[data-rm]').forEach((b) => { b.onclick = async () => {
      await api('/api/platform-icon', { platform: b.dataset.rm, reset: true });
      S.st = await api('/api/state'); renderIcons();
    }; });
  };
  renderIcons();
  $('#sun', m).replaceWith(sun.el);
  $('#sg', m).replaceWith(sg.el);
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const close = () => { bg.remove(); m.remove(); document.removeEventListener('keydown', onKey); };
  document.addEventListener('keydown', onKey);
  bg.onclick = close;
  $('#close', m).onclick = close;
  $('#sunSave', m).onclick = (e) => sun.submit(e.currentTarget);
  $('#sgSave', m).onclick = (e) => sg.submit(e.currentTarget);
  const del = $('#sgDel', m);
  if (del) del.onclick = async () => { await api('/api/sgdb', { key: '' }); S.art = {}; await loadState(); toast('Key removed'); close(); };
  $('#auto', m).onclick = async (e) => {
    e.preventDefault();
    const sw = $('.switch', m.querySelector('#auto'));
    const next = !sw.classList.contains('on');
    sw.classList.toggle('on', next);
    await api('/api/settings', { autoAddNew: next });
    S.st.autoAddNew = next;
  };
  $('#wizard', m).onclick = async () => { close(); await api('/api/settings', { setupDone: false }); S.wizSel = null; S.view = null; loadState(); };
  document.body.append(bg, m);
}

loadState();
