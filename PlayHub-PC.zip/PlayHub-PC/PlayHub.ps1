﻿<#
  PlayHub para PC — "Mi biblioteca"

  Un pequeño programa que corre oculto en tu PC y:
    • detecta tus juegos instalados (Steam, Epic, GOG)
    • te deja elegir cuáles aparecen en el TV y personalizar su arte (página web local)
    • los mantiene sincronizados en Sunshine
    • le entrega al TV tus personalizaciones (nombre, descripción, portada, fondo, logo)

  Uso:
    Install.bat                       installs everything (pide permisos de administrador una vez)
    PlayHub.ps1 -Agent                corre el agente (lo hace Windows solo al iniciar sesión)
    PlayHub.ps1 -Open                 abre "Mi biblioteca" en el navegador (inicia el agente si hace falta)
    PlayHub.ps1 -Uninstall            desinstala
    PlayHub.ps1 -RemoveGames          borra de Sunshine los juegos que agregó PlayHub
#>
[CmdletBinding()]
param(
  [switch]$Install,
  [switch]$Uninstall,
  [switch]$Agent,
  [switch]$Open,
  [switch]$RemoveGames,
  # Usado por Sunshine para abrir un juego en pantalla completa: PlayHub.ps1 -Launch <clave>
  [string]$Launch,
  # Usado por Sunshine al empezar/terminar un juego: PlayHub.ps1 -Cursor hide|show
  [string]$Cursor,
  # Usado por Sunshine al terminar un juego (también al salir con SELECT+START): cierra el .exe
  [string]$Close,
  [int]$Port = 47960,
  # Usados internamente al reabrir el instalador como administrador:
  [string]$ForUser,
  [string]$ForAppData,
  [string]$ForDesktop,
  [string]$ForStartMenu
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

if ($ForAppData) { $env:APPDATA = $ForAppData }   # instalación elevada: usar la carpeta de tu usuario
$AppDir     = Join-Path $env:APPDATA 'PlayHub'
$InstallDir = Join-Path $AppDir 'app'
$CoverDir   = Join-Path $AppDir 'covers'
$CustomDir  = Join-Path $AppDir 'custom'
$TvImgDir   = Join-Path $AppDir 'tv-img'    # copias livianas de tus imágenes para el TV
$ConfigFile = Join-Path $AppDir 'config.json'
$LibFile    = Join-Path $AppDir 'library.json'
$LogFile    = Join-Path $AppDir 'playhub.log'
$TaskName   = 'PlayHub'
$OldTask    = 'PlayHub Sync'
$WebDir     = Join-Path $PSScriptRoot 'web'
$IsWin      = ($env:OS -eq 'Windows_NT')

New-Item -ItemType Directory -Force -Path $AppDir, $CoverDir, $CustomDir, $TvImgDir | Out-Null

# PowerShell 5.1 a veces guarda los arreglos como {"value":[...],"Count":n}. Esto lo evita.
if ($PSVersionTable.PSVersion.Major -lt 6) { Remove-TypeData System.Array -ErrorAction SilentlyContinue }

# =================================================================== utilidades

function Write-Log([string]$msg) {
  $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg
  Write-Host $line
  try {
    if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 1MB) { Move-Item $LogFile "$LogFile.old" -Force }
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
  } catch { }
}

# ConvertFrom-Json de PowerShell 5.1 no tiene -AsHashtable: convertimos a mano.
function ConvertTo-Hash($obj) {
  if ($null -eq $obj) { return $null }
  if ($obj -is [System.Collections.IDictionary]) {
    $h = @{}
    foreach ($k in $obj.Keys) { $h[$k] = ConvertTo-Hash $obj[$k] }
    return $h
  }
  if ($obj -is [pscustomobject]) {
    $h = @{}
    foreach ($p in $obj.PSObject.Properties) { $h[$p.Name] = ConvertTo-Hash $p.Value }
    return $h
  }
  if ($obj -is [System.Collections.IEnumerable] -and $obj -isnot [string]) {
    $list = New-Object System.Collections.ArrayList
    foreach ($i in $obj) { [void]$list.Add((ConvertTo-Hash $i)) }
    return ,$list.ToArray()
  }
  return $obj
}

function Read-JsonHash($path) {
  if (-not (Test-Path $path)) { return $null }
  try { return ConvertTo-Hash (Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null }
}

function Save-JsonFile($path, $obj) {
  $tmp = "$path.tmp"
  $json = ConvertTo-Json -InputObject $obj -Depth 12
  [IO.File]::WriteAllText($tmp, $json, (New-Object Text.UTF8Encoding $false))
  Move-Item $tmp $path -Force
}

function Get-SafeKey([string]$key) { return ($key -replace '[^a-zA-Z0-9_-]', '_') }

function Protect-Text([string]$plain) {
  if (-not $plain) { return '' }
  $sec = ConvertTo-SecureString $plain -AsPlainText -Force
  if ($IsWin) { return 'dpapi:' + (ConvertFrom-SecureString $sec) }                     # cifrado con tu usuario de Windows
  return 'b64:' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($plain))      # solo para pruebas fuera de Windows
}

function Unprotect-Text([string]$stored) {
  if (-not $stored) { return '' }
  try {
    if ($stored.StartsWith('b64:')) { return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($stored.Substring(4))) }
    $s = $stored; if ($s.StartsWith('dpapi:')) { $s = $s.Substring(6) }
    $sec = ConvertTo-SecureString $s
    return [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  } catch { return '' }
}

# Sunshine usa un certificado autofirmado en localhost: lo aceptamos solo en este proceso.
if (-not ('PlayHubTrustAll' -as [type])) {
  Add-Type @"
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
public static class PlayHubTrustAll {
  public static string AllowedHost = "";
  public static bool Accept(object s, X509Certificate c, X509Chain ch, SslPolicyErrors e) {
    if (e == SslPolicyErrors.None) return true;
    HttpWebRequest r = s as HttpWebRequest;
    if (r == null) return false;
    string h = r.RequestUri.Host.ToLowerInvariant();
    // Solo aceptamos el certificado autofirmado de Sunshine; Steam y SteamGridDB se validan normal.
    return h == "localhost" || h == "127.0.0.1" || h == "[::1]" || h == "::1" || (AllowedHost != "" && h == AllowedHost);
  }
  public static void Enable() { ServicePointManager.ServerCertificateValidationCallback = Accept; }
}
"@
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[PlayHubTrustAll]::Enable()

# Invoke-RestMethod de PowerShell 5.1 lee como Latin-1 las respuestas sin "charset" y daña
# nombres con ™, ®, tildes... Por eso leemos los bytes y los decodificamos como UTF-8.
function Invoke-JsonRequest([hashtable]$req) {
  $r = Invoke-WebRequest @req
  $bytes = $r.RawContentStream.ToArray()
  if (-not $bytes -or $bytes.Length -eq 0) { return $null }
  $txt = [Text.Encoding]::UTF8.GetString($bytes)
  if (-not $txt.Trim()) { return $null }
  return ($txt | ConvertFrom-Json)
}

function Invoke-Http([string]$url, [hashtable]$headers) {
  $req = @{ Uri = $url; TimeoutSec = 20; UseBasicParsing = $true; Headers = @{ 'User-Agent' = 'PlayHub/1.1' } }
  if ($headers) { foreach ($k in $headers.Keys) { $req.Headers[$k] = $headers[$k] } }
  return Invoke-JsonRequest $req
}

# =================================================================== configuración

function Get-Config {
  $c = Read-JsonHash $ConfigFile
  if (-not $c) { return $null }
  return @{
    url      = $(if ($c.url) { $c.url } else { 'https://localhost:47990' })
    user     = $c.user
    password = Unprotect-Text $c.password
    sgdbKey  = Unprotect-Text $c.sgdbKey
  }
}

# Ojo: sin [string] en password/sgdbKey, para que $null signifique "no cambiar".
function Save-Config([string]$url, [string]$user, $password, $sgdbKey) {
  $old = Read-JsonHash $ConfigFile
  $c = [ordered]@{
    url      = $url
    user     = $user
    password = $(if ($null -ne $password) { Protect-Text $password } elseif ($old) { $old.password } else { '' })
    sgdbKey  = $(if ($null -ne $sgdbKey) { Protect-Text $sgdbKey } elseif ($old) { $old.sgdbKey } else { '' })
  }
  Save-JsonFile $ConfigFile $c
}

# =================================================================== API de Sunshine

$script:Csrf = $null

function Invoke-Sunshine($cfg, [string]$method, [string]$path, $body) {
  $pair = '{0}:{1}' -f $cfg.user, $cfg.password
  $headers = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair)) }
  if ($script:Csrf) { $headers['X-CSRF-Token'] = $script:Csrf }
  $req = @{ Uri = ($cfg.url.TrimEnd('/') + $path); Method = $method; Headers = $headers; TimeoutSec = 20; UseBasicParsing = $true }
  if ($PSVersionTable.PSVersion.Major -ge 6) { $req.SkipCertificateCheck = $true }
  if ($null -ne $body) {
    $req.Body = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $body -Depth 6 -Compress))
    $req.ContentType = 'application/json; charset=utf-8'
  }
  try { [PlayHubTrustAll]::AllowedHost = ([Uri]$cfg.url).Host.ToLowerInvariant() } catch { }
  return Invoke-JsonRequest $req
}

function Connect-Sunshine($cfg) {
  $script:Csrf = $null
  try {
    $t = Invoke-Sunshine $cfg 'GET' '/api/csrf-token' $null
    if ($t.csrf_token) { $script:Csrf = $t.csrf_token } elseif ($t.token) { $script:Csrf = $t.token }
  } catch { }   # versiones de Sunshine sin CSRF
  return Get-SunshineApps $cfg
}

function Get-SunshineApps($cfg) {
  $r = Invoke-Sunshine $cfg 'GET' '/api/apps' $null
  if ($r -and $r.apps) { return ,@($r.apps) }
  return ,@()
}

function Test-Sunshine($cfg) {
  try { Connect-Sunshine $cfg | Out-Null; return @{ ok = $true } }
  catch {
    $msg = $_.Exception.Message
    if ($msg -match '401|Unauthorized') { $msg = 'Wrong username or password.' }
    elseif ($msg -match 'actively refused|No connection|refused|timed out|tiempo') { $msg = 'Sunshine is not responding. Is it running?' }
    return @{ ok = $false; error = $msg }
  }
}

# =================================================================== detección de juegos

$SkipSteamIds = @(228980, 1070560, 1391110, 1628350, 1493710, 2180100, 1826330, 1887720, 961940, 1420170, 858280, 1054830, 1113280, 1245040, 2348590, 3658110)
$SkipNames = 'Redistributable|Steamworks|Proton|Steam Linux Runtime|Dedicated Server|\bSDK\b|Soundtrack|\bOST\b|Benchmark|Editor$|Wallpaper Engine|SteamVR|Unreal Engine|Launcher$'

function Get-SteamGames {
  $games = @()
  $steamPath = $null
  foreach ($k in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
    try {
      $p = Get-ItemProperty $k -ErrorAction Stop
      if ($p.SteamPath) { $steamPath = $p.SteamPath; break }
      if ($p.InstallPath) { $steamPath = $p.InstallPath; break }
    } catch { }
  }
  if (-not $steamPath) { return $games }
  $steamPath = $steamPath -replace '/', '\'
  $libs = @($steamPath)
  $vdf = Join-Path $steamPath 'steamapps\libraryfolders.vdf'
  if (Test-Path $vdf) {
    $txt = Get-Content $vdf -Raw -Encoding UTF8
    foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
  }
  $seen = @{}
  foreach ($lib in ($libs | Select-Object -Unique)) {
    $apps = Join-Path $lib 'steamapps'
    if (-not (Test-Path $apps)) { continue }
    foreach ($f in Get-ChildItem $apps -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue) {
      try {
        $acf = Get-Content $f.FullName -Raw -Encoding UTF8
        $id = [int]([regex]::Match($acf, '"appid"\s+"(\d+)"').Groups[1].Value)
        $name = [regex]::Match($acf, '"name"\s+"([^"]+)"').Groups[1].Value
        $inst = [regex]::Match($acf, '"installdir"\s+"([^"]+)"').Groups[1].Value
        $instDir = $(if ($inst) { Join-Path $apps ('common\' + $inst) } else { '' })
        $flags = [int]([regex]::Match($acf, '"StateFlags"\s+"(\d+)"').Groups[1].Value)
        if (-not $id -or -not $name -or $seen[$id]) { continue }
        if (($flags -band 4) -eq 0) { continue }
        if ($SkipSteamIds -contains $id -or $name -match $SkipNames) { continue }
        $seen[$id] = $true
        $games += @{ key = "steam:$id"; source = 'Steam'; name = $name; steamId = $id; detached = @("steam://rungameid/$id"); cmd = ''; workdir = ''; installDir = $instDir }
      } catch { }
    }
  }
  return $games
}

function Get-EpicGames {
  $games = @()
  $dir = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
  if (-not (Test-Path $dir)) { return $games }
  foreach ($f in Get-ChildItem $dir -Filter '*.item' -ErrorAction SilentlyContinue) {
    try {
      $m = Get-Content $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($m.bIsIncompleteInstall) { continue }
      if ($m.AppCategories -and -not ($m.AppCategories -contains 'games')) { continue }
      if (-not $m.DisplayName -or $m.DisplayName -match $SkipNames) { continue }
      if ($m.InstallLocation -and -not (Test-Path $m.InstallLocation)) { continue }
      $uri = 'com.epicgames.launcher://apps/{0}%3A{1}%3A{2}?action=launch&silent=true' -f $m.CatalogNamespace, $m.CatalogItemId, $m.AppName
      $games += @{ key = "epic:$($m.AppName)"; source = 'Epic'; name = $m.DisplayName; steamId = $null; detached = @($uri); cmd = ''; workdir = ''; installDir = [string]$m.InstallLocation }
    } catch { }
  }
  return $games
}

function Get-GogGames {
  $games = @()
  foreach ($root in 'HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games', 'HKLM:\SOFTWARE\GOG.com\Games') {
    if (-not (Test-Path $root)) { continue }
    foreach ($k in Get-ChildItem $root -ErrorAction SilentlyContinue) {
      try {
        $p = Get-ItemProperty $k.PSPath
        if (-not $p.gameName -or -not $p.exe -or -not (Test-Path $p.exe)) { continue }
        if ($p.gameName -match $SkipNames) { continue }
        $games += @{ key = "gog:$($p.gameID)"; source = 'GOG'; name = $p.gameName; steamId = $null; detached = @(); cmd = ('"{0}"' -f $p.exe); workdir = $p.path }
      } catch { }
    }
  }
  return $games
}

function Get-InstalledGames {
  $all = @()
  $all += @(Get-SteamGames)
  $all += @(Get-EpicGames)
  $all += @(Get-GogGames)
  $byName = @{}
  $out = @()
  foreach ($g in $all) {
    if (-not $g -or -not $g.name) { continue }
    $n = $g.name.ToLowerInvariant()
    if ($byName[$n]) { continue }
    $byName[$n] = $true
    $out += $g
  }
  $out += @(Get-ManualGames)   # los que agregaste tú (no se mezclan con los detectados)
  return $out
}

# =================================================================== juegos agregados por ti

$LaunchExts = '.exe', '.lnk', '.url', '.bat', '.cmd'

function Get-LaunchSpec([string]$path, [string]$launchArgs) {
  $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
  $dir = Split-Path $path -Parent
  $a = $(if ($launchArgs) { ' ' + $launchArgs.Trim() } else { '' })
  switch ($ext) {
    # .exe: Sunshine lo abre directamente y sabe cuándo terminas de jugar.
    '.exe' { return @{ cmd = ('"{0}"{1}' -f $path, $a); workdir = $dir; detached = @() } }
    '.bat' { return @{ cmd = ('cmd.exe /c ""{0}"{1}"' -f $path, $a); workdir = $dir; detached = @() } }
    '.cmd' { return @{ cmd = ('cmd.exe /c ""{0}"{1}"' -f $path, $a); workdir = $dir; detached = @() } }
    # Accesos directos: los abre Windows, como si les dieras doble clic.
    default { return @{ cmd = ''; workdir = $dir; detached = @(('explorer.exe "{0}"' -f $path)) } }
  }
}

function Get-SuggestedName([string]$path) {
  $base = [IO.Path]::GetFileNameWithoutExtension($path)
  if ([IO.Path]::GetExtension($path).ToLowerInvariant() -ne '.exe') { return $base }   # accesos directos: su nombre suele ser bueno
  $generic = '^(launcher|game|games|client|start|play|app|application|main|bin|binaries|win(32|64)|x(64|86)|unity|unreal|bootstrap|setup|shipping)$'
  # 1. El nombre que trae el propio .exe
  try {
    $vi = (Get-Item -LiteralPath $path -ErrorAction Stop).VersionInfo
    foreach ($n in $vi.ProductName, $vi.FileDescription) {
      $n = ([string]$n).Trim()
      if ($n -and $n.Length -le 60 -and $n -notmatch $generic -and $n -notmatch 'Shipping|\.exe$|Win(32|64)|Unreal|Unity|BootstrapPackaged') { return $n }
    }
  } catch { }
  # 2. El nombre del archivo, sin sufijos técnicos (p. ej. "Juego-Win64-Shipping")
  $clean = $base
  do { $prev = $clean; $clean = ($clean -replace '[-_. ]?(Win64|Win32|x64|x86|Shipping|Launcher|DX1[12]|Vulkan|Steam|EGS|Final|Release)$', '') } while ($clean -ne $prev -and $clean)
  $clean = ($clean -replace '[_]', ' ').Trim()
  $technical = ($base -ne $clean) -or ($clean -match $generic) -or ($clean.Length -le 2)
  # 3. Si el nombre era técnico, usar la carpeta del juego (saltando "Binaries\Win64", "bin"…)
  if ($technical) {
    $dir = Split-Path $path -Parent
    $skipProject = $false
    while ($dir) {
      $leaf = Split-Path $dir -Leaf
      $parent = Split-Path $dir -Parent
      if ($leaf -match '^binaries$') { $skipProject = $true }   # Unreal: <Juego>\<Proyecto>\Binaries\Win64
      elseif ($skipProject -and $parent -and (Split-Path $parent -Leaf)) { $skipProject = $false }
      elseif ($leaf -and $leaf -notmatch $generic -and $leaf -notmatch '^(steamapps|common|program files( \(x86\))?|juegos)$') { return $leaf }
      $dir = $parent
    }
  }
  if ($clean) { return $clean }
  return $base
}

function Get-ManualGames {
  $lib = Get-Library
  $out = @()
  if (-not $lib.manual) { return $out }
  foreach ($k in @($lib.manual.Keys)) {
    $m = $lib.manual[$k]
    if (-not $m.path -or -not (Test-Path -LiteralPath $m.path)) { continue }   # si borras el archivo, desaparece
    $spec = Get-LaunchSpec $m.path $m.args
    $out += @{ key = $k; source = 'Manual'; name = $m.name; steamId = $null; detached = @($spec.detached); cmd = $spec.cmd; workdir = $spec.workdir; path = $m.path }
  }
  return $out
}

function Add-ManualGame([string]$path, [string]$name, [string]$launchArgs) {
  $path = $path.Trim().Trim('"')
  if (-not $path) { throw 'Pick a file.' }
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'I can''t find that file.' }
  $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
  if ($LaunchExts -notcontains $ext) { throw 'Pick an .exe, a shortcut (.lnk / .url) or a .bat.' }
  $lib = Get-Library
  if (-not $lib.manual) { $lib.manual = @{} }
  foreach ($k in @($lib.manual.Keys)) {
    if ($lib.manual[$k].path -eq $path) { throw 'That file is already in your library.' }
  }
  $name = $(if ($name -and $name.Trim()) { $name.Trim() } else { Get-SuggestedName $path })
  $key = 'manual:' + [guid]::NewGuid().ToString('N').Substring(0, 12)
  $lib.manual[$key] = @{ path = $path; name = $name; args = $(if ($launchArgs) { $launchArgs.Trim() } else { '' }) }
  $spec = Get-LaunchSpec $path $launchArgs
  $lib.games[$key] = @{
    key = $key; source = 'Manual'; name = $name; steamId = $null; path = $path
    detached = @($spec.detached); cmd = $spec.cmd; workdir = $spec.workdir
    enabled = $true; decided = $true; installed = $true
    firstSeen = (Get-Date).ToString('s'); controller = $null; metaDone = $false; description = ''; custom = @{}
    sunshineName = $null; coverPng = $null; coverSrc = $null; conflict = $false
  }
  Save-Library
  Add-Work "meta:$key"
  Add-Work 'sunshine'
  Write-Log "Agregado a mano: $name ($path)"
  return $lib.games[$key]
}

function Remove-ManualGame([string]$key) {
  $lib = Get-Library
  if (-not $lib.manual -or -not $lib.manual.ContainsKey($key)) { throw 'Only games you added yourself can be removed.' }
  $lib.manual.Remove($key)
  $g = $lib.games[$key]
  if ($g) { $g.enabled = $false; $g.installed = $false }   # la próxima sincronización lo quita de Sunshine
  Save-Library
  Add-Work 'sunshine'
}

# El selector de archivos de Windows se abre en un proceso aparte para que PlayHub
# siga respondiendo (al TV y a la página) mientras eliges.
$script:Picker = $null

function Start-FilePicker {
  if ($script:Picker -and -not $script:Picker.HasExited) { return }
  $code = @'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Windows.Forms
$owner = New-Object Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Opacity = 0; StartPosition = 'CenterScreen' }
$owner.Show(); $owner.Activate()
$d = New-Object Windows.Forms.OpenFileDialog
$d.Title = 'PlayHub - Pick the game or program'
$d.Filter = 'Games and programs (*.exe, *.lnk, *.url, *.bat)|*.exe;*.lnk;*.url;*.bat;*.cmd|All files (*.*)|*.*'
$d.InitialDirectory = [Environment]::GetFolderPath('ProgramFiles')
$d.DereferenceLinks = $false
if ($d.ShowDialog($owner) -eq [Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($d.FileName) }
$owner.Close()
'@
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = 'powershell.exe'
  $psi.Arguments = '-NoProfile -STA -ExecutionPolicy Bypass -EncodedCommand ' + [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code))
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $script:Picker = [Diagnostics.Process]::Start($psi)
  $script:PickerOut = $script:Picker.StandardOutput.ReadToEndAsync()
}

function Get-FilePickerResult {
  if (-not $script:Picker) { return @{ ok = $false; error = 'No file picker is open.' } }
  if (-not $script:Picker.HasExited -or -not $script:PickerOut.IsCompleted) { return @{ ok = $true; pending = $true } }
  $path = ([string]$script:PickerOut.Result).Trim()
  $script:Picker = $null
  if (-not $path) { return @{ ok = $true; cancelled = $true } }
  return @{ ok = $true; path = $path; name = (Get-SuggestedName $path) }
}

# =================================================================== biblioteca

$script:Lib = $null
$CoverVersion = 2   # súbelo si cambia el tamaño/formato de las portadas para regenerarlas

function Get-Library {
  if ($script:Lib) { return $script:Lib }
  $lib = Read-JsonHash $LibFile
  if (-not $lib) { $lib = @{ version = 1; setupDone = $false; autoAddNew = $false; games = @{}; lastScan = $null; lastSync = $null; syncMessage = '' } }
  if (-not $lib.games) { $lib.games = @{} }
  foreach ($k in @($lib.games.Keys)) {
    $g = $lib.games[$k]
    if (-not $g.custom) { $g.custom = @{} }
    if ($null -eq $g.detached) { $g.detached = @() }
  }
  # La info automática ahora va en inglés: se vuelve a buscar una vez (lo personalizado no se toca).
  if ($lib.lang -ne 'en' -or [int]$lib.metaVer -lt 4) {
    $lib.metaVer = 4
    foreach ($g in @($lib.games.Values)) { $g.metaDone = $false; $g.metaFails = 0; $g.wikiTried = $false; $g.description = ''; $g.descSource = $null }
    $lib.lang = 'en'
  }
  $script:Lib = $lib
  return $lib
}

function Save-Library { Save-JsonFile $LibFile $script:Lib }

# Revisa qué hay instalado. Los juegos nuevos quedan "sin decidir" (no aparecen en el TV
# a menos que actives "agregar juegos nuevos automáticamente").
function Update-Installed {
  $lib = Get-Library
  $found = @(Get-InstalledGames)
  $seen = @{}
  $new = 0
  foreach ($d in $found) {
    $seen[$d.key] = $true
    $g = $lib.games[$d.key]
    if (-not $g) {
      $g = @{
        key = $d.key; source = $d.source; name = $d.name; steamId = $d.steamId
        enabled = [bool]$lib.autoAddNew; decided = [bool]($lib.autoAddNew -and $lib.setupDone)
        firstSeen = (Get-Date).ToString('s'); installed = $true
        controller = $null; metaDone = $false; description = ''; custom = @{}
        sunshineName = $null; coverPng = $null; coverSrc = $null; conflict = $false
      }
      $lib.games[$d.key] = $g
      $new++
    }
    $g.name = $d.name; $g.source = $d.source
    if ($d.steamId) { $g.steamId = $d.steamId }
    $g.detached = @($d.detached); $g.cmd = $d.cmd; $g.workdir = $d.workdir
    if ($d.path) { $g.path = $d.path }
    if ($d.installDir) { $g.installDir = $d.installDir }
    if ($d.source -eq 'Manual') { $g.name = $d.name }
    $g.installed = $true
    if (-not $g.metaDone -or (-not $g.description -and -not $g.wikiTried)) { Add-Work "meta:$($d.key)" }
  }
  foreach ($k in @($lib.games.Keys)) { if (-not $seen[$k]) { $lib.games[$k].installed = $false } }
  $lib.lastScan = (Get-Date).ToString('s')
  Save-Library
  if ($new) { Write-Log "Juegos nuevos detectados: $new" }
  Add-Work 'sunshine'
}

# =================================================================== info de Steam

function Get-Normalized([string]$s) {
  $s = $s.ToLowerInvariant() -replace '[™®©]', ''
  $s = $s -replace "\b(game of the year|goty|definitive|deluxe|ultimate|complete|remastered|enhanced|edition|director'?s cut)\b", ' '
  return (($s -replace '[^a-z0-9 ]+', ' ') -replace '\s+', ' ').Trim()
}

function Get-Similarity([string]$first, [string]$second) {
  # En PowerShell $a y $A son la misma variable: por eso estos nombres.
  $tokA = @((Get-Normalized $first).Split(' ') | Where-Object { $_ })
  $tokB = @((Get-Normalized $second).Split(' ') | Where-Object { $_ })
  if ($tokA.Count -eq 0 -or $tokB.Count -eq 0) { return 0 }
  if (($tokA -join ' ') -eq ($tokB -join ' ')) { return 1 }
  $inter = @($tokA | Where-Object { $tokB -contains $_ }).Count
  return $inter / [Math]::Max($tokA.Count, $tokB.Count)
}

function Find-SteamId([string]$name) {
  # La búsqueda de Steam es exigente: probamos el nombre completo y versiones más cortas.
  $clean = ($name -replace '[™®©]', '').Trim()
  $terms = @($clean)
  foreach ($sep in ' - ', ': ', ' – ') { if ($clean.Contains($sep)) { $terms += $clean.Substring(0, $clean.IndexOf($sep)).Trim() } }
  $terms += (Get-Normalized $clean)
  foreach ($term in ($terms | Where-Object { $_ } | Select-Object -Unique)) {
    $q = [Uri]::EscapeDataString($term)
    $r = Invoke-Http "https://store.steampowered.com/api/storesearch/?term=$q&l=english&cc=US"
    $best = $null; $score = 0
    foreach ($it in $r.items) {
      $s = [Math]::Max((Get-Similarity $name $it.name), (Get-Similarity $term $it.name))
      if ($s -gt $score) { $score = $s; $best = $it }
    }
    if ($best -and $score -ge 0.6) { return [int]$best.id }
  }
  return $null
}

# Busca en Steam: id, soporte de control (full / partial / none) y descripción.
function Update-GameMeta($g) {
  if (-not $g.metaDone) { try {
    if (-not $g.steamId) { $g.steamId = Find-SteamId $g.name }
    if ($g.steamId) {
      $id = $g.steamId
      $d = Invoke-Http "https://store.steampowered.com/api/appdetails?appids=$id&l=english&cc=US"
      $entry = $d.PSObject.Properties["$id"]
      if ($entry -and $entry.Value.success) {
        $data = $entry.Value.data
        # Steam lo indica en controller_support o, a veces, solo en las categorías (28 = completo, 18 = parcial).
        $cats = @($data.categories | ForEach-Object { [int]$_.id })
        if ($data.controller_support) { $g.controller = [string]$data.controller_support }
        elseif ($cats -contains 28) { $g.controller = 'full' }
        elseif ($cats -contains 18) { $g.controller = 'partial' }
        else { $g.controller = 'none' }
        $g.description = ([string]$data.short_description -replace '<[^>]+>', '' -replace '&quot;', '"' -replace '&amp;', '&').Trim()
        if ($data.release_date -and $data.release_date.date) { $g.releaseDate = [string]$data.release_date.date }
        if ($g.description) { $g.descSource = 'Steam' }
      }
    }
    $g.metaDone = $true
  } catch {
    Write-Log "  Sin info de Steam para $($g.name): $($_.Exception.Message)"
    $g.metaFails = 1 + [int]$g.metaFails
    if ($g.metaFails -ge 3) { $g.metaDone = $true }
  } }
  # Sin descripción de Steam: probar Wikipedia (una sola vez por juego).
  if (-not $g.description -and -not $g.wikiTried) {
    $wk = Find-WikiDescription (Get-DisplayName $g)
    if (-not $script:WikiError) { $g.wikiTried = $true }   # si Wikipedia falló, se reintenta en la próxima búsqueda
    if ($wk) { $g.description = $wk.text; $g.descSource = $wk.source; $g.descFor = (Get-DisplayName $g); if ($wk.year) { $g.year = $wk.year }; $g.wikiPlatform = $wk.platform }
  }
}

# Descripción desde Wikipedia (español; si no hay, inglés) para juegos que no están en Steam
# o que Steam no describe: recomps, emuladores, juegos de otras tiendas...
function Find-WikiDescription([string]$name) {
  $clean = ($name -replace '[™®©]', '' -replace '\s+', ' ').Trim()
  $script:WikiError = $false
  $ua = @{ 'User-Agent' = 'PlayHub/1.5 (https://github.com/gvancrue/playhub-tv)' }
  foreach ($w in @(@{ lang = 'en'; hint = 'video game' })) {   # solo en inglés
    try {
      $q = [Uri]::EscapeDataString("$clean $($w.hint)")
      $r = Invoke-Http "https://$($w.lang).wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&srlimit=6&format=json" $ua
      $best = $null; $score = 0
      foreach ($hit in @($r.query.search)) {
        $t = ([string]$hit.title -replace '\s*\((videojuego|video game|[^)]*game[^)]*)\)\s*$', '')
        $sc = Get-Similarity $clean $t
        # "Ocarina of Time" -> "The Legend of Zelda: Ocarina of Time"
        # (el título más corto gana: "Majora's Mask" antes que "Majora's Mask 3D")
        if ($clean.Length -ge 6 -and $t.ToLower().Contains($clean.ToLower())) { $sc = [Math]::Max($sc, 0.8 + 0.15 * $clean.Length / [Math]::Max(1, $t.Length)) }
        if ($sc -gt $score) { $score = $sc; $best = [string]$hit.title }
      }
      if (-not $best -or $score -lt 0.5) { continue }
      $sum = Invoke-Http ("https://$($w.lang).wikipedia.org/api/rest_v1/page/summary/" + [Uri]::EscapeDataString(($best -replace ' ', '_'))) $ua
      if ($sum.type -eq 'disambiguation' -or -not $sum.extract) { continue }
      $txt = ([string]$sum.extract -replace '\s+', ' ').Trim()
      # Una descripción corta, como la de Steam (hasta ~3 oraciones)
      $sentences = [regex]::Split($txt, '(?<=[\.\!\?])\s+')
      $out = ''
      foreach ($sn in $sentences) { if (($out + ' ' + $sn).Length -gt 320 -and $out) { break }; $out = ($out + ' ' + $sn).Trim() }
      $year = $null
      $plat = Find-PlatformInText ([string]$sum.extract)
      if ([string]$sum.description -match '\b(19[5-9]\d|20[0-4]\d)\b') { $year = $Matches[1] }   # "1994 video game"
      return @{ text = $out; source = "Wikipedia ($($w.lang))"; url = [string]$sum.content_urls.desktop.page; year = $year; platform = $plat }
    } catch { $script:WikiError = $true }
  }
  return $null
}

function Get-SteamArt($id, [string]$kind) {
  if (-not $id) { return @() }
  $base = "https://cdn.cloudflare.steamstatic.com/steam/apps/$id"
  switch ($kind) {
    'cover' { return @(@{ url = "$base/library_600x900_2x.jpg"; thumb = "$base/library_600x900.jpg"; source = 'Steam' }) }
    'hero'  { return @(@{ url = "$base/library_hero.jpg"; thumb = "$base/library_hero.jpg"; source = 'Steam' }, @{ url = "$base/page_bg_raw.jpg"; thumb = "$base/page_bg_raw.jpg"; source = 'Steam' }) }
    'logo'  { return @(@{ url = "$base/logo.png"; thumb = "$base/logo.png"; source = 'Steam' }) }
  }
  return @()
}

# =================================================================== SteamGridDB

$script:SgdbIds = @{}
$script:ArtCache = @{}

function Invoke-Sgdb([string]$key, [string]$path) {
  return Invoke-Http ("https://www.steamgriddb.com/api/v2" + $path) @{ Authorization = "Bearer $key" }
}

function Test-SgdbKey([string]$key) {
  try { $r = Invoke-Sgdb $key '/search/autocomplete/portal'; return @{ ok = [bool]$r.success } }
  catch { return @{ ok = $false; error = 'That key didn''t work. Check that you copied all of it.' } }
}

function Get-SgdbGameId([string]$apiKey, $g) {
  if ($g.custom.sgdbId) { return [int]$g.custom.sgdbId }   # el que elegiste buscando
  if ($script:SgdbIds.ContainsKey($g.key)) { return $script:SgdbIds[$g.key] }
  $id = $null
  try {
    if ($g.steamId) {
      $r = Invoke-Sgdb $apiKey "/games/steam/$($g.steamId)"
      if ($r.success -and $r.data) { $id = $r.data.id }
    }
    if (-not $id) {
      $r = Invoke-Sgdb $apiKey ("/search/autocomplete/" + [Uri]::EscapeDataString($g.name))
      if ($r.success -and $r.data -and @($r.data).Count) { $id = @($r.data)[0].id }
    }
  } catch { }
  $script:SgdbIds[$g.key] = $id
  return $id
}

# Buscar en SteamGridDB por nombre (p. ej. "Link's Awakening DX" en vez del original).
function Search-Sgdb([string]$apiKey, [string]$q) {
  $r = Invoke-Sgdb $apiKey ("/search/autocomplete/" + [Uri]::EscapeDataString($q))
  $out = @()
  foreach ($it in @($r.data | Select-Object -First 12)) {
    $year = $null
    if ($it.release_date) { try { $year = ([DateTimeOffset]::FromUnixTimeSeconds([long]$it.release_date)).Year } catch { } }
    $out += [ordered]@{ id = [int]$it.id; name = [string]$it.name; year = $year }
  }
  return $out
}

function Get-ArtOptions($g, [string]$kind) {
  $cacheKey = "$($g.key)|$kind"
  if ($script:ArtCache.ContainsKey($cacheKey)) { return $script:ArtCache[$cacheKey] }
  $list = @(Get-SteamArt $g.steamId $kind)
  $cfg = Get-Config
  if ($cfg -and $cfg.sgdbKey) {
    $gid = Get-SgdbGameId $cfg.sgdbKey $g
    if ($gid) {
      $path = switch ($kind) {
        'cover' { "/grids/game/$gid`?dimensions=600x900,342x482,660x930&types=static&nsfw=false&humor=any" }
        'hero'  { "/heroes/game/$gid`?types=static&nsfw=false" }
        'logo'  { "/logos/game/$gid`?types=static&nsfw=false" }
      }
      try {
        $r = Invoke-Sgdb $cfg.sgdbKey $path
        foreach ($it in @($r.data | Select-Object -First 30)) {
          $list += @{ url = $it.url; thumb = $(if ($it.thumb) { $it.thumb } else { $it.url }); source = 'SteamGridDB'; author = $(if ($it.author) { $it.author.name } else { '' }) }
        }
      } catch { Write-Log "  SteamGridDB falló para $($g.name): $($_.Exception.Message)" }
    }
  }
  $script:ArtCache[$cacheKey] = $list
  return $list
}

# =================================================================== imágenes

function Get-ImageExt([byte[]]$bytes) {
  if ($bytes.Length -ge 4 -and $bytes[0] -eq 0x89 -and $bytes[1] -eq 0x50) { return 'png' }
  if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xD8) { return 'jpg' }
  if ($bytes.Length -ge 12 -and $bytes[8] -eq 0x57 -and $bytes[9] -eq 0x45 -and $bytes[10] -eq 0x42 -and $bytes[11] -eq 0x50) { return 'webp' }
  if ($bytes.Length -ge 3 -and $bytes[0] -eq 0x47 -and $bytes[1] -eq 0x49) { return 'gif' }
  return $null
}

# Guarda una imagen personalizada (subida por ti) y devuelve la ruta.
function Save-CustomImage($g, [string]$kind, [byte[]]$bytes) {
  $ext = Get-ImageExt $bytes
  if (-not $ext -or $ext -eq 'webp') { throw 'Unsupported format. Use PNG or JPG.' }
  $safe = Get-SafeKey $g.key
  Get-ChildItem $CustomDir -Filter "$safe-$kind.*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
  $file = Join-Path $CustomDir "$safe-$kind.$ext"
  [IO.File]::WriteAllBytes($file, $bytes)
  return $file
}

function Get-CoverSource($g) {
  if ($g.custom.cover) { return $g.custom.cover }
  if ($g.steamId) { return "https://cdn.cloudflare.steamstatic.com/steam/apps/$($g.steamId)/library_600x900_2x.jpg" }
  return $null
}

# Sunshine exige PNG: descargamos (o leemos) la portada y la ajustamos a 600x900.
function Update-CoverPng($g) {
  $src = Get-CoverSource $g
  if (-not $src) { $g.coverPng = $null; $g.coverSrc = $null; return }
  if ($g.coverSrc -eq $src -and $g.coverPng -and (Test-Path $g.coverPng) -and $g.coverVer -eq $CoverVersion) { return }
  # Un archivo nuevo por cada portada distinta: así Sunshine (y el TV) notan el cambio.
  $md5 = [Security.Cryptography.MD5]::Create()
  $hash = -join ($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($src + '|' + (Get-Date).Ticks)) | Select-Object -First 4 | ForEach-Object { $_.ToString('x2') })
  $safe = Get-SafeKey $g.key
  $png = Join-Path $CoverDir "$safe-$hash.png"
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('playhub_' + (Get-SafeKey $g.key))
  if ($src -match '^https?://') {
    $urls = @($src)
    if (-not $g.custom.cover -and $g.steamId) { $urls += "https://cdn.cloudflare.steamstatic.com/steam/apps/$($g.steamId)/library_600x900.jpg" }
    $ok = $false
    foreach ($u in $urls) { try { Invoke-WebRequest $u -OutFile $tmp -TimeoutSec 25 -UseBasicParsing -Headers @{ 'User-Agent' = 'PlayHub/1.1' }; $ok = $true; break } catch { } }
    if (-not $ok) { throw "Could not download the cover" }
  } else {
    Copy-Item $src $tmp -Force
  }
  try { Convert-ToCoverPng $tmp $png } finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
  $old = $g.coverPng
  $g.coverPng = $png
  $g.coverSrc = $src
  $g.coverVer = $CoverVersion
  if ($old -and $old -ne $png) { Remove-Item $old -Force -ErrorAction SilentlyContinue }
}

# ------------------------------------------------------------------ imágenes livianas para el TV
# El TV tiene poca memoria: un fondo de SteamGridDB puede venir en 3840x2160 (unos 33 MB al
# dibujarse). Aquí se guardan copias reducidas (fondo 1280 px en JPG, logo 640 px en PNG,
# portada 400x600 en JPG) y el TV recibe esas en vez de las originales.
$TvImgMax = @{ hero = @(1920, 1080); logo = @(1000, 500); cover = @(400, 600) }
$TvImgVersion = 2

function Get-TvImageName($g, [string]$kind) {
  $src = [string]$g.custom[$kind]
  if (-not $src) { return $null }
  $ver = ''
  if ($src -notmatch '^https?://') { try { $ver = (Get-Item $src -ErrorAction Stop).LastWriteTimeUtc.Ticks } catch { return $null } }
  $md5 = [Security.Cryptography.MD5]::Create()
  $hash = -join ($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes("$src|$ver|$TvImgVersion")) | Select-Object -First 6 | ForEach-Object { $_.ToString('x2') })
  $ext = $(if ($kind -eq 'logo') { 'png' } else { 'jpg' })
  return "$(Get-SafeKey $g.key)-$kind-$hash.$ext"
}

function Update-TvImage($g, [string]$kind) {
  $name = Get-TvImageName $g $kind
  if (-not $name) { return }
  $out = Join-Path $TvImgDir $name
  if (Test-Path $out) { return }
  $src = [string]$g.custom[$kind]
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('playhub_tv_' + [Guid]::NewGuid().ToString('N'))
  try {
    if ($src -match '^https?://') { Invoke-WebRequest $src -OutFile $tmp -TimeoutSec 30 -UseBasicParsing -Headers @{ 'User-Agent' = 'PlayHub/1.5' } }
    else { Copy-Item $src $tmp -Force }
    Add-Type -AssemblyName System.Drawing
    $img = [System.Drawing.Image]::FromFile($tmp)
    try {
      $max = $TvImgMax[$kind]
      $scale = [Math]::Min(1.0, [Math]::Min($max[0] / $img.Width, $max[1] / $img.Height))
      if ($kind -eq 'cover') { $scale = [Math]::Min(1.0, [Math]::Max($max[0] / $img.Width, $max[1] / $img.Height)) }
      $w = [Math]::Max(1, [int]($img.Width * $scale)); $h = [Math]::Max(1, [int]($img.Height * $scale))
      $bmp = New-Object System.Drawing.Bitmap $w, $h
      $gr = [System.Drawing.Graphics]::FromImage($bmp)
      $gr.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $gr.DrawImage($img, 0, 0, $w, $h)
      $gr.Dispose()
      $part = "$out.part"
      if ($kind -eq 'logo') { $bmp.Save($part, [System.Drawing.Imaging.ImageFormat]::Png) }
      else {
        $enc = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
        $ep = New-Object System.Drawing.Imaging.EncoderParameters 1
        $ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter ([System.Drawing.Imaging.Encoder]::Quality), ([long]88)
        $bmp.Save($part, $enc, $ep)
      }
      $bmp.Dispose()
    } finally { $img.Dispose() }
    Move-Item $part $out -Force
    # Borrar versiones anteriores de esta misma imagen
    Get-ChildItem $TvImgDir -Filter "$(Get-SafeKey $g.key)-$kind-*" | Where-Object { $_.Name -ne $name } | Remove-Item -Force -ErrorAction SilentlyContinue
  } finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
}

# Lo que el TV recibe: la copia liviana si ya está lista; si no, la original (y se prepara la liviana).
function Get-TvImageRef($g, [string]$kind) {
  $ref = Get-ImageRef $g $kind
  if (-not $ref) { return $null }
  $name = Get-TvImageName $g $kind
  if ($name -and (Test-Path (Join-Path $TvImgDir $name))) { return "/tvimg/$name" }
  if ($name -and $g.tvImgFail -ne $name) { Add-Work "tvimg:$($kind):$($g.key)" }
  return $ref
}

function Convert-ToCoverPng([string]$inFile, [string]$outFile) {
  Add-Type -AssemblyName System.Drawing
  $src = [System.Drawing.Image]::FromFile($inFile)
  try {
    $W = 400; $H = 600   # suficiente para el TV y mucho más liviano que 600x900
    $bmp = New-Object System.Drawing.Bitmap $W, $H
    $gr = [System.Drawing.Graphics]::FromImage($bmp)
    $gr.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $scale = [Math]::Max($W / $src.Width, $H / $src.Height)
    $dw = [int]($src.Width * $scale); $dh = [int]($src.Height * $scale)
    $gr.DrawImage($src, [int](($W - $dw) / 2), [int](($H - $dh) / 2), $dw, $dh)
    $bmp.Save($outFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $gr.Dispose(); $bmp.Dispose()
  } finally { $src.Dispose() }
}

# =================================================================== sincronización con Sunshine

function Get-DisplayName($g) { if ($g.custom.name) { return [string]$g.custom.name } return [string]$g.name }

# El comando que corre Sunshine. Con "pantalla completa" activado (solo juegos .exe), Sunshine
# abre PlayHub, que abre el juego y le pone la ventana en pantalla completa.
function Test-CanFullscreen($g) { return ([string]$g.cmd -match '^"[^"]+\.exe"') }
function Get-AppCmd($g) {
  if ($g.custom.fullscreen -and (Test-CanFullscreen $g)) {
    $ps1 = Join-Path $InstallDir 'PlayHub.ps1'
    return ('powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Launch "{1}"' -f $ps1, $g.key)
  }
  return [string]$g.cmd
}

function New-AppBody($g, [int]$index) {
  return [ordered]@{
    name                      = (Get-DisplayName $g)
    output                    = ''
    cmd                       = (Get-AppCmd $g)
    'working-dir'             = [string]$g.workdir
    detached                  = @($g.detached)
    'prep-cmd'                = @(Get-PrepCmd $g)
    'image-path'              = $(if ($g.coverPng) { [string]$g.coverPng } else { '' })
    'exclude-global-prep-cmd' = $false
    elevated                  = $false
    'auto-detach'             = $true
    'wait-all'                = $true
    'exit-timeout'            = 5
    index                     = $index
  }
}

function Find-AppIndex($apps, [string]$name) {
  if (-not $name) { return -1 }
  $n = $name.Trim().ToLowerInvariant()
  for ($i = 0; $i -lt $apps.Count; $i++) {
    if ($apps[$i].name -and ([string]$apps[$i].name).Trim().ToLowerInvariant() -eq $n) { return $i }
  }
  return -1
}

function Sync-Sunshine {
  $lib = Get-Library
  $cfg = Get-Config
  if (-not $cfg -or -not $cfg.user) { $lib.syncMessage = 'Missing Sunshine setup.'; return }
  try { $apps = Connect-Sunshine $cfg }
  catch { $lib.syncMessage = 'Sunshine is not responding. Is it running?'; $script:NextSunshineRetry = (Get-Date).AddMinutes(2); Save-Library; return }

  $added = 0; $updated = 0; $removed = 0
  foreach ($g in @($lib.games.Values)) {
    $want = $g.enabled -and $g.installed
    if ($want) {
      # Las portadas se preparan aparte (una por vez) para no congelar la página ni el TV.
      $src = Get-CoverSource $g
      if ($src -and ($g.coverSrc -ne $src -or $g.coverVer -ne $CoverVersion) -and $g.coverFailSrc -ne $src) { Add-Work "cover:$($g.key)" }
      $name = Get-DisplayName $g
      $idx = -1
      if ($g.sunshineName) { $idx = Find-AppIndex $apps $g.sunshineName }
      if ($idx -lt 0) {
        $other = Find-AppIndex $apps $name
        if ($other -ge 0) { $g.conflict = $true; continue }   # ya existe una app tuya con ese nombre: no la tocamos
        try {
          Invoke-Sunshine $cfg 'POST' '/api/apps' (New-AppBody $g -1) | Out-Null
          $g.sunshineName = $name; $g.conflict = $false; $added++
          Write-Log "  + $name"
          $apps = Get-SunshineApps $cfg
        } catch { Write-Log "  ! No pude agregar $name`: $($_.Exception.Message)" }
      } else {
        $a = $apps[$idx]
        if ([string]$a.name -ne $name) {
          $other = Find-AppIndex $apps $name
          if ($other -ge 0 -and $other -ne $idx) { $g.conflict = $true; continue }   # ese nombre ya lo usa otra app
        }
        $img = $(if ($g.coverPng) { [string]$g.coverPng } else { '' })
        $needs = ([string]$a.name -ne $name) -or ([string]$a.'image-path' -ne $img) -or ((@($a.detached) -join '|') -ne (@($g.detached) -join '|')) -or ([string]$a.cmd -ne (Get-AppCmd $g)) -or ((@($a.'prep-cmd' | ForEach-Object { "$($_.do)|$($_.undo)" }) -join ';') -ne (@(Get-PrepCmd $g | ForEach-Object { "$($_.do)|$($_.undo)" }) -join ';'))
        if ($needs) {
          try {
            Invoke-Sunshine $cfg 'POST' '/api/apps' (New-AppBody $g $idx) | Out-Null
            $g.sunshineName = $name; $updated++
            $apps = Get-SunshineApps $cfg
          } catch { Write-Log "  ! No pude actualizar $name`: $($_.Exception.Message)" }
        }
        $g.conflict = $false
      }
    } elseif ($g.sunshineName) {
      $idx = Find-AppIndex $apps $g.sunshineName
      if ($idx -lt 0) { $g.sunshineName = $null; continue }
      try {
        Invoke-Sunshine $cfg 'DELETE' "/api/apps/$idx" $null | Out-Null
        Write-Log "  - $($g.sunshineName)"
        $g.sunshineName = $null; $removed++
        $apps = Get-SunshineApps $cfg
      } catch { Write-Log "  ! No pude quitar $($g.sunshineName): $($_.Exception.Message)" }
    }
  }
  $lib.lastSync = (Get-Date).ToString('s')
  $lib.syncMessage = $(if ($added + $updated + $removed) { "Sunshine updated: $added added, $updated changed, $removed removed." } else { 'Sunshine is up to date.' })
  if ($added + $updated + $removed) { Write-Log $lib.syncMessage }
  Save-Library
}

function Remove-ManagedGames {
  $lib = Get-Library
  $cfg = Get-Config
  if (-not $cfg) { Write-Log 'No hay configuración.'; return }
  $apps = Connect-Sunshine $cfg
  foreach ($g in @($lib.games.Values)) {
    if (-not $g.sunshineName) { continue }
    $idx = Find-AppIndex $apps $g.sunshineName
    if ($idx -ge 0) {
      Invoke-Sunshine $cfg 'DELETE' "/api/apps/$idx" $null | Out-Null
      Write-Log "  - $($g.sunshineName)"
      $apps = Get-SunshineApps $cfg
    }
    $g.sunshineName = $null
    $g.enabled = $false
  }
  Save-Library
}

# =================================================================== cola de trabajo
# El agente hace una tarea pequeña a la vez entre peticiones, para que la página
# y el TV siempre respondan rápido.

$script:Work = New-Object System.Collections.ArrayList
$script:NextSunshineRetry = Get-Date

function Add-Work([string]$item) { if (-not $script:Work.Contains($item)) { [void]$script:Work.Add($item) } }

function Invoke-NextWork {
  if ($script:Work.Count -eq 0) { return $false }
  # Sunshine va al final para que primero estén listos los datos de los juegos.
  $item = $null
  foreach ($w in $script:Work) { if ($w -ne 'sunshine') { $item = $w; break } }
  if (-not $item) {
    if ((Get-Date) -lt $script:NextSunshineRetry) { return $false }
    $item = 'sunshine'
  }
  $script:Work.Remove($item)
  try {
    if ($item -eq 'sunshine') { Sync-Sunshine }
    elseif ($item -eq 'scan') { Update-Installed }
    elseif ($item.StartsWith('tvimg:')) {
      $parts = $item.Split(':', 3)
      $g = (Get-Library).games[$parts[2]]
      if ($g) {
        try { Update-TvImage $g $parts[1] }
        catch { $g.tvImgFail = (Get-TvImageName $g $parts[1]); Write-Log "  Imagen liviana ($($parts[1])) de $($g.name): $($_.Exception.Message)" }
      }
    }
    elseif ($item.StartsWith('cover:')) {
      $g = (Get-Library).games[$item.Substring(6)]
      if ($g) {
        $src = Get-CoverSource $g
        try { Update-CoverPng $g; $g.coverFailSrc = $null }
        catch { $g.coverFailSrc = $src; Write-Log "  Portada de $($g.name): $($_.Exception.Message)" }
        Save-Library
        Add-Work 'sunshine'
      }
    }
    elseif ($item.StartsWith('meta:')) {
      $g = (Get-Library).games[$item.Substring(5)]
      if ($g) {
        Update-GameMeta $g
        if (-not $g.metaDone) { Add-Work $item }
        Save-Library
        Start-Sleep -Milliseconds 350   # no saturar la API de Steam
      }
    }
  } catch { Write-Log "Error en '$item': $($_.Exception.Message)" }
  return $true
}

# =================================================================== servidor web local

function Send-Bytes($ctx, [int]$status, [string]$type, [byte[]]$bytes) {
  $res = $ctx.Response
  try {
    $res.StatusCode = $status
    $res.ContentType = $type
    $res.Headers['Cache-Control'] = 'no-store'
    if ($ctx.Request.Url.AbsolutePath -like '/tv/*' -or $ctx.Request.Url.AbsolutePath -like '/img/*') { $res.Headers['Access-Control-Allow-Origin'] = '*' }
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
  } catch { } finally { try { $res.OutputStream.Close() } catch { } }
}

function Send-Json($ctx, $obj, [int]$status = 200) {
  $json = ConvertTo-Json -InputObject $obj -Depth 10 -Compress
  Send-Bytes $ctx $status 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json))
}

function Send-File($ctx, [string]$path, [string]$cache) {
  if (-not $path -or -not (Test-Path $path -PathType Leaf)) { Send-Bytes $ctx 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('404')); return }
  $types = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.jpeg' = 'image/jpeg'; '.gif' = 'image/gif'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon' }
  $ext = [IO.Path]::GetExtension($path).ToLowerInvariant()
  $type = $(if ($types[$ext]) { $types[$ext] } else { 'application/octet-stream' })
  Send-Bytes $ctx 200 $type ([IO.File]::ReadAllBytes($path))
}

function Read-Body($ctx) {
  $reader = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
  $txt = $reader.ReadToEnd()
  $reader.Close()
  if (-not $txt) { return @{} }
  return ConvertTo-Hash ($txt | ConvertFrom-Json)
}

function Test-LocalRequest($ctx) {
  $ip = $ctx.Request.RemoteEndPoint.Address
  if (-not [Net.IPAddress]::IsLoopback($ip)) { return $false }
  # Evita que otra página web abierta en tu navegador lea o cambie tu biblioteca.
  $hostHdr = [string]$ctx.Request.Headers['Host']
  if ($hostHdr -notmatch "^(localhost|127\.0\.0\.1|\[::1\]):$Port$") { return $false }
  $origin = $ctx.Request.Headers['Origin']
  if ($origin -and $origin -notmatch "^http://(localhost|127\.0\.0\.1|\[::1\]):$Port$") { return $false }
  return $true
}

# Las acciones que cambian algo solo se aceptan como POST con JSON (una imagen o un
# enlace de otra página no puede enviarlas).
function Test-JsonPost($ctx) {
  return $ctx.Request.HttpMethod -eq 'POST' -and ([string]$ctx.Request.ContentType) -match '^application/json'
}

function Get-ImageRef($g, [string]$kind) {
  $v = $g.custom[$kind]
  if (-not $v) { return $null }
  if ($v -match '^https?://') { return $v }
  $ver = 0
  try { $ver = (Get-Item $v -ErrorAction Stop).LastWriteTimeUtc.Ticks } catch { }
  return "/img/$(Get-SafeKey $g.key)/$kind`?v=$ver"
}

# Consola original (para emuladores y recomps), adivinada por el programa o la ROM.
$Platforms = 'PC', 'DOS', 'Atari 2600', 'NES', 'SNES', 'N64', 'GameCube', 'Wii', 'Wii U', 'Switch', 'Switch 2', 'Virtual Boy', 'Game Boy', 'Game Boy Color', 'Game Boy Advance', 'Nintendo DS', 'Nintendo 3DS',
  'PlayStation', 'PlayStation 2', 'PlayStation 3', 'PlayStation 4', 'PlayStation 5', 'PSP', 'PS Vita', 'Xbox', 'Xbox 360', 'Xbox One', 'Xbox Series X|S',
  'Master System', 'Genesis', 'Sega CD', 'Saturn', 'Dreamcast', 'Game Gear', 'TurboGrafx-16', 'Neo Geo', 'Arcade', 'Commodore 64', 'Amiga', 'MSX'
function Get-AutoPlatform($g) {
  $t = ("$($g.cmd) $($g.path) $(@($g.detached) -join ' ')").ToLowerInvariant()
  if (-not $t.Trim()) { return $null }
  $rules = [ordered]@{
    '\.(sfc|smc)\b|snes9x|bsnes|zsnes' = 'SNES'
    '\.(z64|n64|v64)\b|recomp|project64|mupen|simple64|rmg\.exe' = 'N64'
    '\.nes\b|mesen|fceux|nestopia' = 'NES'
    '\.gba\b|mgba|visualboy' = 'Game Boy Advance'
    '\.(gb|gbc)\b|sameboy|gambatte' = 'Game Boy'
    '\.nds\b|melonds|desmume' = 'Nintendo DS'
    '\.3ds\b|citra|lime3ds|azahar' = 'Nintendo 3DS'
    '\.(xci|nsp)\b|ryujinx|yuzu|suyu|sudachi|citron' = 'Switch'
    '\.(rvz|gcm|gcz)\b|dolphin' = 'GameCube'
    '\.(wbfs|wad)\b' = 'Wii'
    '\bcemu\b|cemu\.exe' = 'Wii U'
    'duckstation|epsxe|\.cue\b' = 'PlayStation'
    'pcsx2' = 'PlayStation 2'
    'rpcs3' = 'PlayStation 3'
    'ppsspp' = 'PSP'
    'xemu' = 'Xbox'
    'xenia' = 'Xbox 360'
    'flycast|redream|\.cdi\b|\.gdi\b' = 'Dreamcast'
    'kega|genesis_plus|blastem|\.(md|gen|smd)\b' = 'Genesis'
    'shadps4|\bspine\b' = 'PlayStation 4'
    'vita3k' = 'PS Vita'
    'yabause|kronos|mednafen.*saturn|\bssf\b' = 'Saturn'
    'dosbox' = 'DOS'
    'stella' = 'Atari 2600'
    'fusion|\.(sms)\b' = 'Master System'
    '\.gg\b' = 'Game Gear'
    '\.pce\b' = 'TurboGrafx-16'
    'vice|x64sc' = 'Commodore 64'
    'winuae|fs-uae' = 'Amiga'
    'openmsx|bluemsx' = 'MSX'
    'mame' = 'Arcade'
  }
  foreach ($k in $rules.Keys) { if ($t -match $k) { return $rules[$k] } }
  return $null
}
# "…published by Nintendo for the Super Nintendo Entertainment System" -> SNES (la primera consola que se nombra)
function Find-PlatformInText([string]$text) {
  if (-not $text) { return $null }
  $rules = [ordered]@{
    'Super Nintendo Entertainment System|Super NES|\bSNES\b|Super Famicom' = 'SNES'
    'Nintendo 64' = 'N64'
    'Nintendo Entertainment System|\bFamicom\b' = 'NES'
    'Game Boy Advance' = 'Game Boy Advance'
    'Game Boy Color' = 'Game Boy Color'
    'Game Boy\b(?! (Color|Advance))' = 'Game Boy'
    'Nintendo 3DS' = 'Nintendo 3DS'
    'Nintendo DS\b' = 'Nintendo DS'
    'GameCube' = 'GameCube'
    'Wii U' = 'Wii U'
    '\bWii\b' = 'Wii'
    'Nintendo Switch\b(?! 2)' = 'Switch'
    'PlayStation Portable' = 'PSP'
    'PlayStation 5' = 'PlayStation 5'
    'PlayStation 4' = 'PlayStation 4'
    'PlayStation Vita' = 'PS Vita'
    'PlayStation 3' = 'PlayStation 3'
    'PlayStation 2' = 'PlayStation 2'
    'PlayStation\b(?! [2-5]| Portable| Vita)' = 'PlayStation'
    'Xbox Series X' = 'Xbox Series X|S'
    'Xbox One' = 'Xbox One'
    'Nintendo Switch 2' = 'Switch 2'
    'Sega Saturn' = 'Saturn'
    'Master System' = 'Master System'
    'Game Gear' = 'Game Gear'
    'Sega CD|Mega-CD' = 'Sega CD'
    'TurboGrafx|PC Engine' = 'TurboGrafx-16'
    'Neo Geo' = 'Neo Geo'
    'Atari 2600' = 'Atari 2600'
    'Virtual Boy' = 'Virtual Boy'
    'Commodore 64' = 'Commodore 64'
    '\bAmiga\b' = 'Amiga'
    '\bMS-DOS\b' = 'DOS'
    'Xbox 360' = 'Xbox 360'
    'Xbox\b(?! (360|One|Series))' = 'Xbox'
    'Sega Genesis|Mega Drive' = 'Genesis'
    'Dreamcast' = 'Dreamcast'
  }
  $best = $null; $bestAt = [int]::MaxValue; $bestLen = 0
  foreach ($k in $rules.Keys) {
    $m = [regex]::Match($text, $k)
    if ($m.Success -and ($m.Index -lt $bestAt -or ($m.Index -eq $bestAt -and $m.Length -gt $bestLen))) { $best = $rules[$k]; $bestAt = $m.Index; $bestLen = $m.Length }
  }
  return $best
}

function Get-Platform($g) {
  if ($g.custom.platform) { return [string]$g.custom.platform }
  $p = Get-AutoPlatform $g
  if ($p) { return $p }
  # Juegos agregados a mano (emuladores, recomps): la consola que dice Wikipedia.
  if ($g.source -eq 'Manual' -and $g.wikiPlatform) { return [string]$g.wikiPlatform }
  return $null
}

# Ocultar el puntero del mouse durante el juego: "Automático" lo oculta salvo en juegos de mouse y teclado.
function Test-HideMouse($g) {
  $m = [string]$g.custom.mouse
  if ($m -eq 'hide') { return $true }
  if ($m -eq 'show') { return $false }
  return ((Get-Controller $g) -ne 'none')
}
# Al terminar el juego (por SELECT+START, desde Moonlight o porque se cerró), Sunshine corre el
# "undo": vuelve el puntero y se asegura de que el juego quede cerrado en el PC. Hace falta
# porque muchos juegos se le escapan a Sunshine: los que abre Steam/Epic, los .bat, los
# accesos directos, y .exe como los recomp/decomp que abren otro proceso.
#
# Qué se cierra según el tipo de juego:
#   .exe (agregado por ti, GOG)   → ese .exe, y lo que corra desde su carpeta si es propia
#   acceso directo .lnk a un .exe → igual que el .exe al que apunta
#   .bat / .cmd                   → lo que corra desde la carpeta del .bat, si es propia
#   Steam / Epic                  → lo que corra desde la carpeta de instalación del juego
#   .url de otras tiendas         → nada (no sabemos dónde está el juego)
function Get-ShortcutTarget([string]$lnk) {
  try { return [string](New-Object -ComObject WScript.Shell).CreateShortcut($lnk).TargetPath } catch { return '' }
}
function Get-GameTarget($g) {
  $exe = $null; $dir = $null
  if ([string]$g.cmd -match '^"([^"]+\.exe)"') { $exe = $Matches[1] }
  elseif ($g.path -and ([string]$g.path) -match '\.(bat|cmd)$') { $dir = Split-Path ([string]$g.path) }
  elseif ($g.path -and ([string]$g.path) -match '\.lnk$') {
    $t = Get-ShortcutTarget ([string]$g.path)
    if ($t -match '\.exe$') { $exe = $t } elseif ($t -and (Test-Path -LiteralPath $t -PathType Container)) { $dir = $t }
  }
  elseif ($g.installDir) { $dir = [string]$g.installDir }
  if ($exe -and -not $dir) { $dir = Split-Path $exe }
  if (-not $exe -and -not $dir) { return $null }
  return @{ exe = $exe; dir = $(if ($dir) { $dir.TrimEnd('\') } else { $null }) }
}
# ¿Es una carpeta "del juego"? Nunca cerramos todo lo de Program Files, el Escritorio, etc.
function Test-OwnGameDir([string]$dir) {
  if (-not $dir) { return $false }
  $parts = @($dir -split '\\' | Where-Object { $_ })
  if ($parts.Count -lt 2) { return $false }
  $u = $env:USERPROFILE
  $general = @($env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $u, $env:APPDATA, $env:LOCALAPPDATA,
    [Environment]::GetFolderPath('Desktop'), "$u\Desktop", "$u\Downloads", "$u\Documents", "$u\OneDrive", "$u\OneDrive\Desktop", "$u\OneDrive\Documents") |
    Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') }
  if ($general | Where-Object { $_ -ieq $dir }) { return $false }
  if ($dir -match '\\steamapps\\common$' -or $dir -match '\\(Epic Games|GOG Games|Games)$') { return $false }
  return $true
}
function Get-PrepCmd($g) {
  $hide = Test-HideMouse $g
  $close = [bool](Get-GameTarget $g)
  if (-not $hide -and -not $close) { return @() }
  $ps1 = Join-Path $InstallDir 'PlayHub.ps1'
  $base = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}"' -f $ps1
  $do = $(if ($hide) { $base + ' -Cursor hide' } else { 'cmd.exe /c exit 0' })
  $undo = $base + $(if ($close) { ' -Close "{0}"' -f $g.key } else { '' }) + $(if ($hide) { ' -Cursor show' } else { '' })
  return @([ordered]@{ do = $do; undo = $undo; elevated = $false })
}

# Cierra el juego en el PC. Primero le pide que se cierre bien; a los 2 s, a la fuerza.
function Stop-GameByKey([string]$key) {
  $lib = Read-JsonHash $LibFile
  $g = $(if ($lib -and $lib.games) { $lib.games[$key] } else { $null })
  if (-not $g) { Write-Log "Cerrar juego: no encontré $key"; return }
  $t = Get-GameTarget $g
  if (-not $t) { return }
  $ownDir = Test-OwnGameDir $t.dir
  $skip = 'steam', 'steamwebhelper', 'steamservice', 'epicgameslauncher', 'galaxyclient', 'sunshine', 'powershell', 'explorer'
  $me = $PID
  $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Id -ne $me -and $_.Path -and ($skip -notcontains $_.ProcessName.ToLowerInvariant()) -and
    (($t.exe -and $_.Path -ieq $t.exe) -or ($ownDir -and $_.Path.StartsWith($t.dir + '\', [StringComparison]::OrdinalIgnoreCase)))
  })
  if (-not $procs.Count) { Write-Log "Cerrar juego: $($g.name) ya estaba cerrado"; return }
  Write-Log "Cerrando $($g.name) en el PC: $(($procs | ForEach-Object { $_.ProcessName }) -join ', ')"
  foreach ($p in $procs) { try { $p.CloseMainWindow() | Out-Null } catch { } }
  Start-Sleep -Milliseconds 2000
  foreach ($p in $procs) { try { $p.Refresh(); if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } } catch { } }
}

# Íconos de consola: los subes tú en Ajustes (uno por consola) y salen en la etiqueta del TV.
function Get-PlatformSlug([string]$p) { return ($p.ToLowerInvariant() -replace '[^a-z0-9]+', '-').Trim('-') }
function Get-PlatformIconFile([string]$p) {
  if (-not $p) { return $null }
  return (Get-ChildItem $CustomDir -Filter "platform-$(Get-PlatformSlug $p).*" -ErrorAction SilentlyContinue | Select-Object -First 1)
}
function Get-PlatformIconRef([string]$p) {
  $f = Get-PlatformIconFile $p
  if (-not $f) { return $null }
  return "/pimg/$(Get-PlatformSlug $p)?v=$($f.LastWriteTimeUtc.Ticks)"
}

# Tipo de control: el que elegiste en el editor manda sobre lo que dice Steam.
function Get-Controller($g) { if ($g.custom.controller) { return [string]$g.custom.controller } return $g.controller }

function Get-PublicGame($g) {
  $hasSteam = [bool]$g.steamId
  return [ordered]@{
    key = $g.key; source = $g.source; name = $g.name; displayName = (Get-DisplayName $g)
    steamId = $g.steamId; enabled = [bool]$g.enabled; decided = [bool]$g.decided; installed = [bool]$g.installed
    controller = (Get-Controller $g); autoController = $g.controller; metaDone = [bool]$g.metaDone; conflict = [bool]$g.conflict
    inSunshine = [bool]$g.sunshineName
    canFullscreen = (Test-CanFullscreen $g)
    autoYear = $(if ($g.year) { $g.year } elseif ($g.releaseDate -and ([string]$g.releaseDate -match '(\d{4})')) { $Matches[1] } else { $null })
    autoPlatform = $(if (Get-AutoPlatform $g) { Get-AutoPlatform $g } elseif ($g.source -eq 'Manual') { $g.wikiPlatform } else { $null })
    hideMouseAuto = ((Get-Controller $g) -ne 'none')
    path = $g.path
    manual = ($g.source -eq 'Manual')
    description = $(if ($g.custom.description) { $g.custom.description } else { $g.description })
    descSource = $(if ($g.custom.description) { 'You' } else { $g.descSource })
    custom = [ordered]@{
      name = $g.custom.name; description = $g.custom.description; controller = $g.custom.controller; fullscreen = $g.custom.fullscreen; platform = $g.custom.platform; mouse = $g.custom.mouse; hideTag = [bool]$g.custom.hideTag; sgdbName = $g.custom.sgdbName; year = $g.custom.year
      cover = (Get-ImageRef $g 'cover'); hero = (Get-ImageRef $g 'hero'); logo = (Get-ImageRef $g 'logo')
    }
    defaults = [ordered]@{
      cover = $(if ($hasSteam) { "https://cdn.cloudflare.steamstatic.com/steam/apps/$($g.steamId)/library_600x900.jpg" } else { $null })
      hero  = $(if ($hasSteam) { "https://cdn.cloudflare.steamstatic.com/steam/apps/$($g.steamId)/library_hero.jpg" } else { $null })
      logo  = $(if ($hasSteam) { "https://cdn.cloudflare.steamstatic.com/steam/apps/$($g.steamId)/logo.png" } else { $null })
      description = $g.description
    }
  }
}

function Get-StateObject {
  $lib = Get-Library
  $cfg = Get-Config
  $games = @($lib.games.Values | Where-Object { $_.installed } | Sort-Object { (Get-DisplayName $_) } | ForEach-Object { Get-PublicGame $_ })
  $pendingMeta = @($script:Work | Where-Object { $_ -like 'meta:*' }).Count
  return [ordered]@{
    configured = [bool]($cfg -and $cfg.user)
    sunshineUrl = $(if ($cfg) { $cfg.url } else { 'https://localhost:47990' })
    sunshineUser = $(if ($cfg) { $cfg.user } else { '' })
    hasSgdbKey = [bool]($cfg -and $cfg.sgdbKey)
    setupDone = [bool]$lib.setupDone
    autoAddNew = [bool]$lib.autoAddNew
    order = @($(if ($lib.order) { $lib.order } else { @() }))
    platforms = $Platforms
    platformIcons = @($Platforms | Where-Object { Get-PlatformIconFile $_ } | ForEach-Object { [ordered]@{ platform = $_; url = (Get-PlatformIconRef $_) } })
    platformsInUse = @($lib.games.Values | Where-Object { $_.enabled -and $_.installed } | ForEach-Object { Get-Platform $_ } | Where-Object { $_ -and $_ -ne 'PC' } | Sort-Object -Unique)
    lanMode = $script:LanMode
    computer = [Environment]::MachineName
    lastSync = $lib.lastSync
    syncMessage = $lib.syncMessage
    busy = ($script:Work.Count -gt 0)
    pendingMeta = $pendingMeta
    games = $games
  }
}

# Lo que el TV lee: solo los juegos que elegiste, con tus personalizaciones.
function Get-TvLibrary {
  $lib = Get-Library
  $list = @()
  foreach ($g in @($lib.games.Values)) {
    if (-not ($g.enabled -and $g.installed -and $g.sunshineName)) { continue }
    $order = $null
    if ($lib.order) { $i = [array]::IndexOf(@($lib.order), $g.key); if ($i -ge 0) { $order = $i } }
    $desc = $g.custom.description
    # Si no está en Steam, el TV no encuentra la descripción solo: se la mandamos (p. ej. de Wikipedia).
    if (-not $desc -and -not $g.steamId -and $g.description) { $desc = $g.description }
    $list += [ordered]@{
      sunshineName = $g.sunshineName
      name = (Get-DisplayName $g)
      order = $order
      description = $desc
      steamId = $g.steamId
      controller = (Get-Controller $g)
      platform = $(if ((Get-Platform $g) -and (Get-Platform $g) -ne 'PC') { Get-Platform $g } else { $null })
      platformIcon = (Get-PlatformIconRef (Get-Platform $g))
      hideTag = [bool]$g.custom.hideTag
      coverKey = $(if ($g.coverPng) { [IO.Path]::GetFileNameWithoutExtension([string]$g.coverPng) } else { $null })
      year = $(if ($g.custom.year) { $g.custom.year } else { $g.year })
      releaseDate = $(if ($g.custom.year) { $null } else { $g.releaseDate })
      yearForce = [bool]$g.custom.year
      cover = (Get-TvImageRef $g 'cover')
      hero = (Get-TvImageRef $g 'hero')
      logo = (Get-TvImageRef $g 'logo')
    }
  }
  return [ordered]@{ version = 1; computer = [Environment]::MachineName; games = $list }
}

function Invoke-Route($ctx) {
  $req = $ctx.Request
  $path = $req.Url.AbsolutePath
  $method = $req.HttpMethod

  # ---------- para el TV (red local, solo lectura)
  if ($path -eq '/tv/library.json') { return Send-Json $ctx (Get-TvLibrary) }
  if ($path -match '^/img/([A-Za-z0-9_-]+)/(cover|hero|logo)$') {
    $f = Get-ChildItem $CustomDir -Filter "$($Matches[1])-$($Matches[2]).*" -ErrorAction SilentlyContinue | Select-Object -First 1
    return Send-File $ctx $(if ($f) { $f.FullName } else { $null })
  }
  if ($path -match '^/pimg/([a-z0-9-]+)$') {
    $f = Get-ChildItem $CustomDir -Filter "platform-$($Matches[1]).*" -ErrorAction SilentlyContinue | Select-Object -First 1
    return Send-File $ctx $(if ($f) { $f.FullName } else { $null })
  }
  if ($path -match '^/tvimg/([A-Za-z0-9_.-]+)$') {
    $f = Join-Path $TvImgDir $Matches[1]
    return Send-File $ctx $(if (Test-Path $f -PathType Leaf) { $f } else { $null })
  }
  if ($path -eq '/ping') { return Send-Json $ctx @{ ok = $true; app = 'PlayHub'; version = 1 } }

  # ---------- página "Mi biblioteca" y su API (solo desde este PC)
  if (-not (Test-LocalRequest $ctx)) { return Send-Json $ctx @{ ok = $false; error = 'Only from this PC' } 403 }

  if ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) { return Send-File $ctx (Join-Path $WebDir 'index.html') }
  if ($method -eq 'GET' -and $path -match '^/(app\.js|style\.css|logo\.svg)$') { return Send-File $ctx (Join-Path $WebDir $Matches[1]) }

  $lib = Get-Library
  if ($path -like '/api/*' -and $path -ne '/api/state' -and $path -ne '/api/art' -and -not (Test-JsonPost $ctx)) {
    return Send-Json $ctx @{ ok = $false; error = 'Method not allowed' } 405
  }
  switch -Regex ($path) {
    '^/api/state$' { return Send-Json $ctx (Get-StateObject) }

    '^/api/sunshine$' {
      $b = Read-Body $ctx
      $cfgOld = Get-Config
      $pass = $(if ($b.password) { [string]$b.password } elseif ($cfgOld) { $cfgOld.password } else { '' })
      $test = @{ url = [string]$b.url; user = [string]$b.user; password = $pass }
      if (-not $test.url) { $test.url = 'https://localhost:47990' }
      $r = Test-Sunshine $test
      if ($r.ok) {
        Save-Config $test.url $test.user $pass $null
        Add-Work 'sunshine'
      }
      return Send-Json $ctx $r
    }

    '^/api/sgdb$' {
      $b = Read-Body $ctx
      $cfg = Get-Config
      if (-not $cfg) { return Send-Json $ctx @{ ok = $false; error = 'Set up Sunshine first.' } }
      $key = ([string]$b.key).Trim()
      if ($key) {
        $r = Test-SgdbKey $key
        if (-not $r.ok) { return Send-Json $ctx $r }
      }
      Save-Config $cfg.url $cfg.user $null $key
      $script:ArtCache = @{}; $script:SgdbIds = @{}
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/settings$' {
      $b = Read-Body $ctx
      if ($b.ContainsKey('autoAddNew')) { $lib.autoAddNew = [bool]$b.autoAddNew }
      if ($b.ContainsKey('setupDone')) { $lib.setupDone = [bool]$b.setupDone }
      Save-Library
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/select$' {
      $b = Read-Body $ctx
      foreach ($k in @($b.keys)) {
        $g = $lib.games[[string]$k]
        if ($g) { $g.enabled = [bool]$b.enabled; $g.decided = $true }
      }
      Save-Library
      Add-Work 'sunshine'
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/decide-all$' {
      foreach ($g in @($lib.games.Values)) { $g.decided = $true }
      Save-Library
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/game$' {
      $b = Read-Body $ctx
      $g = $lib.games[[string]$b.key]
      if (-not $g) { return Send-Json $ctx @{ ok = $false; error = 'Game not found' } 404 }
      foreach ($f in 'name', 'description') {
        if ($b.ContainsKey($f)) {
          $v = ([string]$b[$f]).Trim()
          if ($v) { $g.custom[$f] = $v } else { $g.custom.Remove($f) }
        }
      }
      if ($b.ContainsKey('fullscreen')) {
        $v = [string]$b.fullscreen
        if ($v -in 'borderless', 'altenter', 'f11') { $g.custom.fullscreen = $v } else { $g.custom.Remove('fullscreen') }
        Add-Work 'sunshine'   # el comando del juego en Sunshine cambia
      }
      if ($b.ContainsKey('year')) {
        $v = ([string]$b.year).Trim()
        if ($v -match '^(19[5-9]\d|20\d\d)$') { $g.custom.year = $v } elseif (-not $v) { $g.custom.Remove('year') }
        else { return Send-Json $ctx @{ ok = $false; error = 'The year should look like 1994.' } }
      }
      if ($b.ContainsKey('hideTag')) {
        if ($b.hideTag) { $g.custom.hideTag = $true } else { $g.custom.Remove('hideTag') }
      }
      if ($b.ContainsKey('platform')) {
        $v = [string]$b.platform
        if ($Platforms -contains $v) { $g.custom.platform = $v } else { $g.custom.Remove('platform') }
      }
      if ($b.ContainsKey('mouse')) {
        $v = [string]$b.mouse
        if ($v -in 'hide', 'show') { $g.custom.mouse = $v } else { $g.custom.Remove('mouse') }
        Add-Work 'sunshine'
      }
      if ($b.ContainsKey('controller')) {
        $v = [string]$b.controller
        if ($v -in 'full', 'partial', 'none') { $g.custom.controller = $v } else { $g.custom.Remove('controller') }
        Add-Work 'sunshine'   # cambia si se oculta el puntero
      }
      # Si le cambiaste el nombre y la descripción venía de Wikipedia, la buscamos de nuevo con el nombre nuevo.
      if (-not $g.steamId -and ($g.descSource -notmatch 'Steam') -and $g.descFor -ne (Get-DisplayName $g)) {
        $wk = Find-WikiDescription (Get-DisplayName $g)
        if ($wk) { $g.description = $wk.text; $g.descSource = $wk.source; $g.descFor = (Get-DisplayName $g); if ($wk.year) { $g.year = $wk.year }; $g.wikiPlatform = $wk.platform }
      }
      Save-Library
      Add-Work 'sunshine'
      return Send-Json $ctx @{ ok = $true; game = (Get-PublicGame $g) }
    }

    '^/api/image$' {
      $b = Read-Body $ctx
      $g = $lib.games[[string]$b.key]
      $kind = [string]$b.kind
      if (-not $g -or @('cover', 'hero', 'logo') -notcontains $kind) { return Send-Json $ctx @{ ok = $false; error = 'Invalid data' } 400 }
      try {
        if ($b.reset) {
          $g.custom.Remove($kind)
          Get-ChildItem $CustomDir -Filter "$(Get-SafeKey $g.key)-$kind.*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        } elseif ($b.url) {
          if ([string]$b.url -notmatch '^https://') { throw 'Invalid URL' }
          $g.custom[$kind] = [string]$b.url
        } elseif ($b.data) {
          $bytes = [Convert]::FromBase64String(([string]$b.data -replace '^data:[^,]+,', ''))
          if ($bytes.Length -gt 15MB) { throw 'The image is too big (max. 15 MB).' }
          $g.custom[$kind] = Save-CustomImage $g $kind $bytes
        }
        if ($kind -eq 'cover') { Add-Work 'sunshine' }
        Save-Library
        return Send-Json $ctx @{ ok = $true; game = (Get-PublicGame $g) }
      } catch { return Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } }
    }

    '^/api/art$' {
      $g = $lib.games[[string]$req.QueryString['key']]
      $kind = [string]$req.QueryString['kind']
      if (-not $g) { return Send-Json $ctx @{ ok = $false; error = 'Game not found' } 404 }
      $cfgA = Get-Config
      return Send-Json $ctx @{ ok = $true; options = @(Get-ArtOptions $g $kind); hasSgdbKey = [bool]($cfgA -and $cfgA.sgdbKey) }
    }

    '^/api/sgdb-search$' {
      $b = Read-Body $ctx
      $cfgS = Get-Config
      if (-not ($cfgS -and $cfgS.sgdbKey)) { return Send-Json $ctx @{ ok = $false; error = 'Add a SteamGridDB key in Settings first.' } }
      try { return Send-Json $ctx @{ ok = $true; results = @(Search-Sgdb $cfgS.sgdbKey ([string]$b.q)) } }
      catch { return Send-Json $ctx @{ ok = $false; error = "SteamGridDB didn't answer: $($_.Exception.Message)" } }
    }

    '^/api/sgdb-pick$' {
      $b = Read-Body $ctx
      $g = $lib.games[[string]$b.key]
      if (-not $g) { return Send-Json $ctx @{ ok = $false; error = 'Game not found' } 404 }
      if ($b.id) { $g.custom.sgdbId = [int]$b.id; $g.custom.sgdbName = [string]$b.name }
      else { $g.custom.Remove('sgdbId'); $g.custom.Remove('sgdbName') }
      foreach ($k in 'cover', 'hero', 'logo') { $script:ArtCache.Remove("$($g.key)|$k") }
      $script:SgdbIds.Remove($g.key)
      Save-Library
      return Send-Json $ctx @{ ok = $true; game = (Get-PublicGame $g) }
    }

    '^/api/platform-icon$' {
      $b = Read-Body $ctx
      $p = [string]$b.platform
      if ($Platforms -notcontains $p) { return Send-Json $ctx @{ ok = $false; error = 'Unknown console' } 400 }
      try {
        Get-ChildItem $CustomDir -Filter "platform-$(Get-PlatformSlug $p).*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        if (-not $b.reset) {
          $bytes = [Convert]::FromBase64String(([string]$b.data -replace '^data:[^,]+,', ''))
          if ($bytes.Length -gt 2MB) { throw 'The icon is too big (max. 2 MB).' }
          $ext = Get-ImageExt $bytes
          if ($ext -ne 'png' -and $ext -ne 'jpg') { throw 'Use a PNG (ideally with a transparent background) or a JPG.' }
          [IO.File]::WriteAllBytes((Join-Path $CustomDir "platform-$(Get-PlatformSlug $p).$ext"), $bytes)
        }
        return Send-Json $ctx @{ ok = $true }
      } catch { return Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } }
    }

    '^/api/order$' {
      $b = Read-Body $ctx
      if ($b.reset) { $lib.order = $null }
      else { $lib.order = @(@($b.keys) | ForEach-Object { [string]$_ } | Where-Object { $lib.games.ContainsKey($_) }) }
      Save-Library
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/describe$' {
      $b = Read-Body $ctx
      $g = $lib.games[[string]$b.key]
      if (-not $g) { return Send-Json $ctx @{ ok = $false; error = 'Game not found' } 404 }
      $nm = $(if ($b.name) { [string]$b.name } else { Get-DisplayName $g })
      $wk = Find-WikiDescription $nm
      if (-not $wk) { return Send-Json $ctx @{ ok = $false; error = "No Wikipedia description found for ""$nm""." } }
      return Send-Json $ctx @{ ok = $true; text = $wk.text; source = $wk.source; url = $wk.url }
    }

    '^/api/rescan$' {
      Add-Work 'scan'
      return Send-Json $ctx @{ ok = $true }
    }

    '^/api/pick-file$' {
      if (-not $IsWin) { return Send-Json $ctx @{ ok = $false; error = 'The picker only works on Windows. Paste the path.' } }
      try { Start-FilePicker; return Send-Json $ctx @{ ok = $true } }
      catch { return Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } }
    }

    '^/api/pick-file-result$' { return Send-Json $ctx (Get-FilePickerResult) }

    '^/api/suggest-name$' {
      $b = Read-Body $ctx
      $pth = ([string]$b.path).Trim().Trim('"')
      if (-not $pth -or -not (Test-Path -LiteralPath $pth -PathType Leaf)) { return Send-Json $ctx @{ ok = $false; error = 'I can''t find that file.' } }
      return Send-Json $ctx @{ ok = $true; name = (Get-SuggestedName $pth) }
    }

    '^/api/manual/add$' {
      $b = Read-Body $ctx
      try {
        $g = Add-ManualGame ([string]$b.path) ([string]$b.name) ([string]$b.args)
        return Send-Json $ctx @{ ok = $true; game = (Get-PublicGame $g) }
      } catch { return Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } }
    }

    '^/api/manual/remove$' {
      $b = Read-Body $ctx
      try { Remove-ManualGame ([string]$b.key); return Send-Json $ctx @{ ok = $true } }
      catch { return Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } }
    }
  }
  Send-Json $ctx @{ ok = $false; error = 'Not found' } 404
}

$script:LanMode = $false

function Start-Agent {
  $mutex = New-Object Threading.Mutex($false, 'PlayHubAgent')
  if (-not $mutex.WaitOne(0)) { Write-Log 'El agente ya está corriendo.'; return }
  if ($IsWin) { Set-MousePointer $false }   # por si un juego terminó sin devolver el puntero
  try { Clear-OldFiles } catch { Write-Log "Limpieza: $($_.Exception.Message)" }

  $listener = New-Object Net.HttpListener
  $listener.Prefixes.Add("http://+:$Port/")
  try { $listener.Start(); $script:LanMode = $true }
  catch {
    # Sin permiso para escuchar en la red: al menos funciona la página en este PC.
    Write-Log "Sin acceso de red ($($_.Exception.Message)). Run Install.bat so el TV pueda leer tu biblioteca."
    $listener = New-Object Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$Port/")
    $listener.Start()
    $script:LanMode = $false
  }
  Write-Log "PlayHub listo en http://localhost:$Port/ (red local: $script:LanMode)"

  Add-Work 'scan'
  $nextScan = (Get-Date).AddMinutes(30)
  $pending = $listener.GetContextAsync()
  while ($listener.IsListening) {
    $ready = $false
    try { $ready = $pending.Wait(150) }
    catch {
      Write-Log "Conexión fallida: $($_.Exception.Message)"
      $pending = $listener.GetContextAsync()
      continue
    }
    if ($ready) {
      $ctx = $pending.Result
      $pending = $listener.GetContextAsync()
      try { Invoke-Route $ctx }
      catch {
        Write-Log "Error en $($ctx.Request.Url.AbsolutePath): $($_.Exception.Message)"
        try { Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } 500 } catch { }
      }
      continue
    }
    if ((Get-Date) -gt $nextScan) { Add-Work 'scan'; $nextScan = (Get-Date).AddMinutes(30) }
    try { [void](Invoke-NextWork) } catch { Write-Log "Error: $($_.Exception.Message)" }
  }
}

# =================================================================== instalación

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-AgentUp {
  try { $r = Invoke-RestMethod "http://localhost:$Port/ping" -TimeoutSec 2 -UseBasicParsing; return [bool]$r.ok } catch { return $false }
}

function Start-AgentHidden {
  $vbs = Join-Path $InstallDir 'PlayHub-Hidden.vbs'
  if (Test-Path $vbs) { Start-Process 'wscript.exe' -ArgumentList ('"{0}"' -f $vbs) }
  else { Start-Process 'powershell.exe' -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath), '-Agent' }
}

function Open-Library {
  if (-not (Test-AgentUp)) {
    Start-AgentHidden
    for ($i = 0; $i -lt 40 -and -not (Test-AgentUp); $i++) { Start-Sleep -Milliseconds 250 }
  }
  Start-Process "http://localhost:$Port/"
}

function Stop-Agents {
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '^(powershell|pwsh)\.exe$' -and $_.CommandLine -match 'PlayHub\.ps1.*-Agent' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Invoke-Netsh([string]$what, [string[]]$netshArgs) {
  $out = & netsh @netshArgs 2>&1
  if ($LASTEXITCODE -ne 0) { Write-Host "  ! $what failed: $($out -join ' ')" -ForegroundColor Yellow; return $false }
  return $true
}

function Install-PlayHub {
  if (-not (Test-Admin)) {
    # Reabrir como administrador (solo hace falta para la red y el firewall), pero diciéndole
    # quién eres tú: si Windows pide la contraseña de otra cuenta, todo queda igual a tu nombre.
    $me = [Security.Principal.WindowsIdentity]::GetCurrent()
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath), '-Install',
      '-ForUser', ('"{0}"' -f $me.Name),
      '-ForAppData', ('"{0}"' -f $env:APPDATA),
      '-ForDesktop', ('"{0}"' -f [Environment]::GetFolderPath('Desktop')),
      '-ForStartMenu', ('"{0}"' -f (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs')))
    try { Start-Process 'powershell.exe' -Verb RunAs -ArgumentList $argList }
    catch { Write-Host '  Administrator permission was not granted. Open Install.bat again and accept.' -ForegroundColor Red; Start-Sleep 5 }
    return
  }
  $user = $(if ($ForUser) { $ForUser } else { [Security.Principal.WindowsIdentity]::GetCurrent().Name })
  $desktop = $(if ($ForDesktop) { $ForDesktop } else { [Environment]::GetFolderPath('Desktop') })
  $startMenu = $(if ($ForStartMenu) { $ForStartMenu } else { Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs' })
  $sid = (New-Object Security.Principal.NTAccount $user).Translate([Security.Principal.SecurityIdentifier]).Value

  Write-Host ''
  Write-Host "  Installing PlayHub for $user…" -ForegroundColor Cyan

  # 0. Cerrar una versión anterior que esté corriendo
  Stop-Agents
  try { Unregister-ScheduledTask -TaskName $OldTask -Confirm:$false -ErrorAction Stop } catch { }

  # 1. Copiar archivos
  New-Item -ItemType Directory -Force -Path $InstallDir, (Join-Path $InstallDir 'web') | Out-Null
  if ($PSCommandPath -ne (Join-Path $InstallDir 'PlayHub.ps1')) {
    Copy-Item $PSCommandPath (Join-Path $InstallDir 'PlayHub.ps1') -Force
    Copy-Item (Join-Path $WebDir '*') (Join-Path $InstallDir 'web') -Recurse -Force
  }
  $target = Join-Path $InstallDir 'PlayHub.ps1'
  $vbs = Join-Path $InstallDir 'PlayHub-Hidden.vbs'
  Set-Content -Path $vbs -Encoding Unicode -Value @(
    'Set sh = CreateObject("WScript.Shell")',
    ('sh.Run "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $target + '"" -Agent", 0, False')
  )

  # 2. Permitir que el TV lea la biblioteca (solo desde tu red local)
  & netsh http delete urlacl url="http://+:$Port/" 2>&1 | Out-Null
  $okUrl = Invoke-Netsh 'Permiso de red' @('http', 'add', 'urlacl', "url=http://+:$Port/", "sddl=D:(A;;GX;;;$sid)")
  & netsh advfirewall firewall delete rule name="PlayHub" 2>&1 | Out-Null
  $okFw = Invoke-Netsh 'Regla del firewall' @('advfirewall', 'firewall', 'add', 'rule', 'name=PlayHub', 'dir=in', 'action=allow', 'protocol=TCP', "localport=$Port", 'profile=any', 'remoteip=localsubnet')
  if ($okUrl -and $okFw) { Write-Host '  Access from the TV: OK' -ForegroundColor Green }
  else { Write-Host '  The TV might not see your customizations (games will still show up).' -ForegroundColor Yellow }

  # 3. Iniciar con Windows, oculto y como tu usuario normal (no como administrador)
  $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ('"{0}"' -f $vbs)
  $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
  $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description 'PlayHub: tu biblioteca de juegos para el TV.' -Force | Out-Null
  Write-Host '  Start with Windows: OK' -ForegroundColor Green

  # 4. Acceso directo en el escritorio y en el menú Inicio
  $shell = New-Object -ComObject WScript.Shell
  foreach ($dir in $desktop, $startMenu) {
    if (-not (Test-Path $dir)) { continue }
    Remove-Item (Join-Path $dir 'PlayHub - Mi biblioteca.lnk') -Force -ErrorAction SilentlyContinue   # nombre viejo
    $lnk = $shell.CreateShortcut((Join-Path $dir 'PlayHub - My library.lnk'))
    $lnk.TargetPath = 'powershell.exe'
    $lnk.Arguments = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Open' -f $target)
    $lnk.WindowStyle = 7
    $lnk.IconLocation = "$env:SystemRoot\System32\imageres.dll,186"
    $lnk.Description = 'Pick and customize your PlayHub games'
    $lnk.Save()
  }
  Write-Host '  Shortcut "PlayHub - My library": OK' -ForegroundColor Green

  # 5. Arrancar el agente con la tarea (corre como tu usuario) y abrir la página
  Start-ScheduledTask -TaskName $TaskName
  Write-Host ''
  Write-Host '  Opening "My library" in your browser…' -ForegroundColor Cyan
  for ($i = 0; $i -lt 60 -and -not (Test-AgentUp); $i++) { Start-Sleep -Milliseconds 250 }
  if (Test-AgentUp) { Start-Process "http://localhost:$Port/" }
  else { Write-Host '  PlayHub is taking a while to start. Open "PlayHub - My library" from the desktop.' -ForegroundColor Yellow; Start-Sleep 6 }
  Start-Sleep -Seconds 2
}

function Uninstall-PlayHub {
  if (-not (Test-Admin)) {
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath), '-Uninstall',
      '-ForDesktop', ('"{0}"' -f [Environment]::GetFolderPath('Desktop')),
      '-ForStartMenu', ('"{0}"' -f (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs')))
    Start-Process 'powershell.exe' -Verb RunAs -ArgumentList $argList
    return
  }
  $desktop = $(if ($ForDesktop) { $ForDesktop } else { [Environment]::GetFolderPath('Desktop') })
  $startMenu = $(if ($ForStartMenu) { $ForStartMenu } else { Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs' })
  foreach ($t in $TaskName, $OldTask) { try { Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction Stop } catch { } }
  Stop-Agents
  & netsh http delete urlacl url="http://+:$Port/" 2>&1 | Out-Null
  & netsh advfirewall firewall delete rule name="PlayHub" 2>&1 | Out-Null
  foreach ($dir in $desktop, $startMenu) { Remove-Item (Join-Path $dir 'PlayHub - Mi biblioteca.lnk'), (Join-Path $dir 'PlayHub - My library.lnk') -Force -ErrorAction SilentlyContinue }
  Write-Host 'PlayHub uninstalled. Your games are still in Sunshine (use -RemoveGames to remove them).' -ForegroundColor Green
  Start-Sleep -Seconds 3
}

# Limpieza al arrancar: portadas e imágenes que ya no usa ningún juego, temporales viejos.
function Clear-OldFiles {
  $lib = Get-Library
  $games = @($lib.games.Values)
  $keepCovers = @{}; foreach ($g in $games) { if ($g.coverPng) { $keepCovers[[IO.Path]::GetFileName([string]$g.coverPng)] = $true } }
  $n = 0
  Get-ChildItem $CoverDir -File -ErrorAction SilentlyContinue | Where-Object { -not $keepCovers[$_.Name] } | ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue; $n++ }
  $keepTv = @{}
  foreach ($g in $games) { foreach ($k in 'cover', 'hero', 'logo') { $nm = Get-TvImageName $g $k; if ($nm) { $keepTv[$nm] = $true } } }
  Get-ChildItem $TvImgDir -File -ErrorAction SilentlyContinue | Where-Object { -not $keepTv[$_.Name] } | ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue; $n++ }
  $safeKeys = @{}; foreach ($g in $games) { $safeKeys[(Get-SafeKey $g.key)] = $true }
  Get-ChildItem $CustomDir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike 'platform-*' -and $_.Name -match '^(.+)-(cover|hero|logo)\.\w+$' -and -not $safeKeys[$Matches[1]] } | ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue; $n++ }
  Get-ChildItem ([IO.Path]::GetTempPath()) -Filter 'playhub_*' -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue; $n++ }
  if ($n) { Write-Log "Limpieza: $n archivos viejos borrados" }
}

# =================================================================== pantalla completa

$FullscreenCode = @'
using System;
using System.Runtime.InteropServices;
public static class PhWin {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  const int GWL_STYLE = -16, GWL_EXSTYLE = -20;
  const int WS_CAPTION = 0x00C00000, WS_THICKFRAME = 0x00040000, WS_MINIMIZE = 0x20000000, WS_MAXIMIZE = 0x01000000, WS_SYSMENU = 0x00080000;
  const int WS_EX_DLGMODALFRAME = 0x1, WS_EX_CLIENTEDGE = 0x200, WS_EX_STATICEDGE = 0x20000;
  static RECT Monitor(IntPtr h) { var mi = new MONITORINFO(); mi.cbSize = Marshal.SizeOf(mi); GetMonitorInfo(MonitorFromWindow(h, 2), ref mi); return mi.rcMonitor; }
  // ¿La ventana ya cubre toda la pantalla?
  public static bool IsFull(IntPtr h) { RECT r; GetWindowRect(h, out r); var m = Monitor(h); return r.L <= m.L && r.T <= m.T && r.R >= m.R && r.B >= m.B; }
  // "Pantalla completa sin bordes": quita el marco y estira la ventana a toda la pantalla.
  public static void Borderless(IntPtr h) {
    int st = GetWindowLong(h, GWL_STYLE) & ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZE | WS_MAXIMIZE | WS_SYSMENU);
    SetWindowLong(h, GWL_STYLE, st);
    int ex = GetWindowLong(h, GWL_EXSTYLE) & ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE);
    SetWindowLong(h, GWL_EXSTYLE, ex);
    var m = Monitor(h);
    SetWindowPos(h, IntPtr.Zero, m.L, m.T, m.R - m.L, m.B - m.T, 0x0020 | 0x0040);   // FRAMECHANGED | SHOWWINDOW
    SetForegroundWindow(h);
  }
  // Atajo de teclado (Alt+Enter o F11) para juegos que tienen su propia pantalla completa.
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
  [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
  static void Key(byte vk, bool up) { keybd_event(vk, (byte)MapVirtualKey(vk, 0), up ? 2u : 0u, UIntPtr.Zero); }
  public static void Keys(IntPtr h, bool altEnter) {
    // Windows no deja que un programa en segundo plano traiga una ventana al frente...
    // salvo justo después de una pulsación de teclado: por eso el Alt suelto antes.
    Key(0x12, false); Key(0x12, true);
    SetForegroundWindow(h);
    System.Threading.Thread.Sleep(250);
    if (GetForegroundWindow() == h) {
      if (altEnter) { Key(0x12, false); Key(0x0D, false); System.Threading.Thread.Sleep(40); Key(0x0D, true); Key(0x12, true); }
      else { Key(0x7A, false); System.Threading.Thread.Sleep(40); Key(0x7A, true); }
    } else {
      // Plan B: mandar la tecla directo a la ventana del juego.
      uint scan = MapVirtualKey(altEnter ? 0x0Du : 0x7Au, 0);
      uint flags = 1u | (scan << 16) | (altEnter ? (1u << 29) : 0u);
      IntPtr down = new IntPtr(unchecked((int)flags));
      IntPtr up = new IntPtr(unchecked((int)(flags | (3u << 30))));
      if (altEnter) { PostMessage(h, 0x0104, (IntPtr)0x0D, down); PostMessage(h, 0x0105, (IntPtr)0x0D, up); }
      else { PostMessage(h, 0x0100, (IntPtr)0x7A, down); PostMessage(h, 0x0101, (IntPtr)0x7A, up); }
    }
  }
}
'@

function Get-GameWindow($proc, [string]$dir) {
  $cands = @()
  try { $proc.Refresh(); if (-not $proc.HasExited) { $cands += $proc } } catch { }
  # Algunos juegos abren otro proceso (un lanzador que abre el juego de verdad): buscamos en la misma carpeta.
  $cands += @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $proc.Id -and $_.Path -and $_.Path.StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) })
  foreach ($c in $cands) {
    try { $h = $c.MainWindowHandle; if ($h -ne [IntPtr]::Zero -and [PhWin]::IsWindowVisible($h)) { return $h } } catch { }
  }
  return [IntPtr]::Zero
}

function Start-GameFullscreen([string]$key) {
  $lib = Read-JsonHash $LibFile
  $g = $(if ($lib -and $lib.games) { $lib.games[$key] } else { $null })
  if (-not $g) { Write-Log "Pantalla completa: no encontré el juego $key"; return }
  if (-not ([string]$g.cmd -match '^"([^"]+)"\s*(.*)$')) { Write-Log "Pantalla completa: $($g.name) no es un .exe"; return }
  $exe = $Matches[1]; $gameArgs = $Matches[2]
  $dir = $(if ($g.workdir) { [string]$g.workdir } else { Split-Path $exe })
  $mode = $(if ($g.custom -and $g.custom.fullscreen) { [string]$g.custom.fullscreen } else { 'borderless' })
  Write-Log "Abriendo $($g.name) en pantalla completa ($mode)"
  $sp = @{ FilePath = $exe; WorkingDirectory = $dir; PassThru = $true }
  if ($gameArgs) { $sp.ArgumentList = $gameArgs }
  $p = Start-Process @sp
  try {
    Add-Type -TypeDefinition $FullscreenCode -ErrorAction SilentlyContinue
    # Esperar la ventana del juego (hasta 90 s).
    $h = [IntPtr]::Zero
    for ($i = 0; $i -lt 180 -and $h -eq [IntPtr]::Zero; $i++) { Start-Sleep -Milliseconds 500; $h = Get-GameWindow $p $dir }
    if ($h -ne [IntPtr]::Zero) {
      if ($mode -eq 'altenter' -or $mode -eq 'f11') {
        Start-Sleep -Milliseconds 600   # apenas el juego muestra su ventana
        if (-not [PhWin]::IsFull($h)) { [PhWin]::Keys($h, ($mode -eq 'altenter')) }
        # Si el juego no hizo caso (aún cargando), una vez más.
        Start-Sleep -Seconds 3
        $h2 = Get-GameWindow $p $dir
        if ($h2 -ne [IntPtr]::Zero -and -not [PhWin]::IsFull($h2)) { [PhWin]::Keys($h2, ($mode -eq 'altenter')) }
      } else {
        Start-Sleep -Milliseconds 1500   # dejar que el juego termine de crear su ventana
        # Algunos juegos cambian el tamaño de su ventana al cargar: lo revisamos unos segundos más.
        for ($k = 0; $k -lt 8; $k++) {
          $h2 = Get-GameWindow $p $dir
          if ($h2 -ne [IntPtr]::Zero) { $h = $h2 }
          if (-not [PhWin]::IsFull($h)) { [PhWin]::Borderless($h) }
          Start-Sleep -Seconds 2
        }
      }
    } else { Write-Log "  No apareció la ventana de $($g.name)" }
  } catch { Write-Log "  Pantalla completa: $($_.Exception.Message)" }
  # Sunshine considera que el juego sigue abierto mientras este proceso viva.
  try { $p.WaitForExit() } catch { }
  while (@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) }).Count) { Start-Sleep -Seconds 2 }
}

# =================================================================== puntero del mouse

$CursorCode = @'
using System;
using System.Runtime.InteropServices;
public static class PhCursor {
  [DllImport("user32.dll")] static extern IntPtr CreateCursor(IntPtr inst, int x, int y, int w, int h, byte[] andMask, byte[] xorMask);
  [DllImport("user32.dll")] static extern bool SetSystemCursor(IntPtr cur, uint id);
  [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint action, uint param, IntPtr vparam, uint winIni);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern int GetSystemMetrics(int i);
  static readonly uint[] Ids = { 32512, 32513, 32514, 32515, 32516, 32640, 32641, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650, 32651 };
  // Cambia todos los punteros del sistema por uno transparente.
  public static void Hide() {
    byte[] andMask = new byte[128], xorMask = new byte[128];
    for (int i = 0; i < 128; i++) { andMask[i] = 0xFF; xorMask[i] = 0; }
    foreach (uint id in Ids) SetSystemCursor(CreateCursor(IntPtr.Zero, 0, 0, 32, 32, andMask, xorMask), id);
    SetCursorPos(GetSystemMetrics(0) - 1, GetSystemMetrics(1) / 2);   // y lo aparta a un lado
  }
  // Vuelve a los punteros normales de Windows.
  public static void Show() { SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0); }
}
'@

function Set-MousePointer([bool]$hide) {
  try {
    Add-Type -TypeDefinition $CursorCode -ErrorAction SilentlyContinue
    if ($hide) { [PhCursor]::Hide() } else { [PhCursor]::Show() }
  } catch { Write-Log "Puntero: $($_.Exception.Message)" }
}

# =================================================================== main

if ($Close) { try { Stop-GameByKey $Close } catch { Write-Log "Cerrar juego: $($_.Exception.Message)" } }
if ($Cursor) { Set-MousePointer ($Cursor -eq 'hide') }
elseif ($Close) { }
elseif ($Launch) { Start-GameFullscreen $Launch }
elseif ($Install) { Install-PlayHub }
elseif ($Uninstall) { Uninstall-PlayHub }
elseif ($RemoveGames) { Remove-ManagedGames }
elseif ($Agent) { Start-Agent }
elseif ($Open) { Open-Library }
else { Open-Library }
