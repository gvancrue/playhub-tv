@echo off
chcp 65001 >nul
title PlayHub - Setup
echo.
echo   Installing PlayHub. Windows will ask for administrator permission:
echo   it's only so the TV can read your library over your home network.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PlayHub.ps1" -Install
